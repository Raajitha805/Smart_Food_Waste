(function () {
  "use strict";

  var S = window.Store;
  var $ = function (sel, root) { return (root || document).querySelector(sel); };
  var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  var PAGE_META = {
    overview: { title: "Overview", sub: "Today across your food rescue network" },
    post: { title: "Post surplus food", sub: "Share what is left over — we will find the nearest receiver" },
    donations: { title: "Donation board", sub: "Every surplus tray, from post to proof of delivery" },
    pickups: { title: "Pickups", sub: "Routes, safety checks and handover confirmation" },
    impact: { title: "Impact dashboard", sub: "Meals rescued, emissions avoided and partner performance" }
  };

  var PERSONAS = [
    { role: "donor", name: "Sunrise Canteen", sub: "Donor · You", initials: "SC", avatar: "" },
    { role: "ngo", name: "Asha Community Kitchen", sub: "Receiver · Community kitchen", initials: "AK", avatar: "avatar-amber" },
    { role: "volunteer", name: "Arjun K.", sub: "Volunteer · Bike", initials: "AK", avatar: "avatar-blue" }
  ];

  var DEMO_FOOD = [];
  var state = {
    page: "overview",
    filter: "all",
    search: "",
    postPhoto: null,
    modalPhoto: null,
    matchTimers: [],
    lastRenderPage: null
  };

  var modal = document.getElementById("modal");
  var modalShell = document.getElementById("modalShell");

  /* ------------------------------------------------------------
     Small helpers
     ------------------------------------------------------------ */
  function esc(value) {
    return String(value == null ? "" : value).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function icon(name, cls) {
    return '<svg class="icon ' + (cls || "") + '" aria-hidden="true"><use href="#i-' + name + '"></use></svg>';
  }

  function statusPill(status) {
    var meta = S.STATUS[status] || S.STATUS.available;
    return '<span class="pill pill-' + meta.tone + '">' + meta.label + "</span>";
  }

  function dietLabel(diet) {
    return diet === "nonveg" ? "Non-vegetarian" : diet === "mixed" ? "Mixed" : "Vegetarian";
  }

  function catMeta(category) {
    var map = {
      "Cooked meal": { icon: "utensils", cls: "", slug: "cooked" },
      "Bakery": { icon: "box", cls: "media-bakery", slug: "bakery" },
      "Produce": { icon: "leaf", cls: "media-produce", slug: "produce" },
      "Dairy": { icon: "plate", cls: "media-dairy", slug: "dairy" },
      "Packaged": { icon: "box", cls: "media-packaged", slug: "packaged" }
    };
    return map[category] || map["Cooked meal"];
  }

  function donorName(don) {
    var d = S.donorById(don.donorId);
    return d ? d.name : "Unknown kitchen";
  }

  function ngoName(don) {
    var n = don.matchedNgoId ? S.ngoById(don.matchedNgoId) : null;
    return n ? n.name : "";
  }

  function avatarMarkup(name, short, extra) {
    return '<span class="avatar ' + (extra || "") + '">' + esc(short || initials(name)) + "</span>";
  }

  function initials(name) {
    return String(name || "")
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map(function (p) { return p[0]; })
      .join("")
      .toUpperCase();
  }

  function freshnessMarkup(don) {
    var f = S.freshness(don);
    var cls = f.pct < 25 ? "crit" : f.pct < 55 ? "warn" : "";
    var text = f.expired ? "Safe window closed" : "Safe for another " + S.duration(f.left);
    return '<div class="fresh">' +
      '<div class="fresh-top"><span>' + icon("clock") + "Freshness window</span><strong>" + text + "</strong></div>" +
      '<div class="fresh-track"><div class="fresh-fill ' + cls + '" style="width:' + f.pct.toFixed(1) + '%"></div></div>' +
      "</div>";
  }

  function notifTone(kind) {
    if (kind === "accept") return "tone-amber";
    if (kind === "pickup" || kind === "proof") return "tone-blue";
    if (kind === "deliver") return "";
    return "";
  }

  function notifIcon(kind) {
    if (kind === "accept") return "shield";
    if (kind === "pickup") return "truck";
    if (kind === "proof") return "camera";
    if (kind === "deliver") return "check";
    return "plus";
  }

  function mapOuter(don) {
    return '<div class="map-outer">' +
      '<div class="map" data-map-donation="' + don.id + '" aria-label="Route map"></div>' +
      '<div class="map-legend">' +
        '<span><span class="legend-dot" style="background:#0F6B4F"></span>Donor</span>' +
        '<span><span class="legend-dot" style="background:#D3922C"></span>Receiver</span>' +
        '<span><span class="legend-dot" style="background:#2E6BD6"></span>Volunteer</span>' +
      "</div>" +
      '<span class="map-chip">Simulated map</span>' +
    "</div>";
  }

  function statCard(o) {
    return '<div class="stat-card">' +
      '<div class="stat-top">' +
        '<span class="stat-icon ' + (o.tone || "tone-green") + '">' + icon(o.icon) + "</span>" +
        (o.badge || "") +
      "</div>" +
      '<div class="stat-value"><span class="count" data-count="' + o.value + '">' + S.fmtNum(o.value) + "</span>" +
        (o.suffix ? "<small>" + o.suffix + "</small>" : "") +
      "</div>" +
      '<div class="stat-label">' + o.label + "</div>" +
      '<div class="stat-sub">' + (o.sub || "") + "</div>" +
    "</div>";
  }

  function kpiCard(o) {
    return '<div class="kpi">' +
      '<div class="kpi-top"><span class="kpi-icon ' + (o.tone || "tone-green") + '">' + icon(o.icon) + "</span></div>" +
      '<div class="kpi-value"><span class="count" data-count="' + o.value + '">' + S.fmtNum(o.value) + "</span>" +
        (o.suffix ? "<small>" + o.suffix + "</small>" : "") +
      "</div>" +
      '<div class="kpi-label">' + o.label + "</div>" +
      '<div class="kpi-sub">' + (o.sub || "") + "</div>" +
    "</div>";
  }

  function animateCounters() {
    if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    $$(".count").forEach(function (el) {
      var target = Number(el.getAttribute("data-count")) || 0;
      if (target === 0) { el.textContent = "0"; return; }
      var start = performance.now();
      var duration = 720;
      function tick(now) {
        var p = Math.min(1, (now - start) / duration);
        var eased = 1 - Math.pow(1 - p, 3);
        el.textContent = S.fmtNum(Math.round(target * eased));
        if (p < 1) requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
    });
  }

  function toast(message, kind) {
    var stack = document.getElementById("toasts");
    var el = document.createElement("div");
    el.className = "toast" + (kind === "error" ? " error" : "");
    el.innerHTML = icon(kind === "error" ? "alert" : "check") + "<div>" + esc(message) + "</div>";
    stack.appendChild(el);
    setTimeout(function () {
      el.classList.add("out");
      setTimeout(function () { el.remove(); }, 260);
    }, 3800);
  }

  /* ------------------------------------------------------------
     Routing + shell chrome
     ------------------------------------------------------------ */
  function pageFromHash() {
    var raw = location.hash.replace(/^#\/?/, "").split("?")[0];
    return PAGE_META[raw] ? raw : "overview";
  }

  function navigate(page) {
    if (pageFromHash() === page) {
      render();
      return;
    }
    location.hash = "#/" + page;
  }

  function personaOptionsMarkup(kind) {
    var current = S.persona().role;
    return PERSONAS.map(function (p) {
      return '<button class="persona-item ' + (p.role === current ? "active" : "") + '" data-action="persona" data-role="' + p.role + '">' +
        '<span class="avatar ' + p.avatar + '">' + p.initials + "</span>" +
        '<span class="persona-meta"><strong>' + esc(p.name) + "</strong><small>" + esc(p.sub) + "</small></span>" +
        '<span class="persona-dot"></span>' +
      "</button>";
    }).join("");
  }

  function notificationsMarkup() {
    var acts = S.activity().slice(0, 6);
    if (!acts.length) return '<div class="notif-empty">No activity yet. Post food to get started.</div>';
    var html = '<div class="dropdown-title">Notifications</div>';
    html += acts.map(function (a) {
      var don = a.donationId ? S.getDonation(a.donationId) : null;
      return '<button class="notif-item" data-action="open-notification" data-donation="' + (don ? don.id : "") + '">' +
        '<span class="notif-icon ' + notifTone(a.kind) + '">' + icon(notifIcon(a.kind)) + "</span>" +
        '<span class="notif-main"><span class="notif-text">' + esc(a.text) + "</span>" +
        '<span class="notif-time">' + S.timeAgo(a.at) + "</span></span>" +
      "</button>";
    }).join("");
    html += '<div class="notif-foot"><span class="notif-time">Latest updates</span>' +
      '<button class="btn-link" data-action="go-page" data-page="donations">Open board ' + icon("arrow") + "</button></div>";
    return html;
  }

  function renderChrome(page) {
    var meta = PAGE_META[page];
    var me = S.persona();
    document.getElementById("pageTitle").textContent = meta.title;
    document.getElementById("pageSub").textContent = meta.sub;
    document.getElementById("roleTag").textContent = me.label;
    document.getElementById("dateChip").textContent = new Date().toLocaleDateString("en-GB", {
      weekday: "short", day: "numeric", month: "short", year: "numeric"
    });
    document.getElementById("personaAvatar").textContent = me.initials;
    document.getElementById("personaAvatar").className = "avatar avatar-sm " + (me.role === "ngo" ? "avatar-amber" : me.role === "volunteer" ? "avatar-blue" : "");

    $$("[data-nav]").forEach(function (link) {
      var active = link.getAttribute("data-nav") === page;
      link.classList.toggle("active", active);
      if (active) link.setAttribute("aria-current", "page");
      else link.removeAttribute("aria-current");
    });

    document.getElementById("personaList").innerHTML = personaOptionsMarkup("sidebar");
    document.getElementById("personaDropdown").innerHTML =
      '<div class="dropdown-title">Viewing as</div>' + personaOptionsMarkup("dropdown");

    updateBellBadge();
    var bellDropdown = document.getElementById("bellDropdown");
    bellDropdown.innerHTML = notificationsMarkup();
  }

  function updateBellBadge() {
    var badge = document.getElementById("bellBadge");
    var count = S.unreadCount();
    badge.textContent = count;
    badge.hidden = count === 0;
  }

  function closeDropdowns() {
    $$(".dropdown.open").forEach(function (d) { d.classList.remove("open"); });
  }

  /* ------------------------------------------------------------
     Hero + shared sections
     ------------------------------------------------------------ */
  function floatingChip(cls, iconName, title, sub) {
    return '<div class="float-chip ' + cls + '"><span class="fc-icon">' + icon(iconName) + "</span>" +
      "<div><strong>" + esc(title) + "</strong><span>" + esc(sub) + "</span></div></div>";
  }

  function heroMarkup() {
    var role = S.persona().role;
    var m = S.metrics();
    var donor = S.donors[0];
    var available = m.available;
    var ngoAccepted = S.state.donations.filter(function (d) {
      return d.matchedNgoId === "n1" && ["matched", "pickup", "picked_up"].indexOf(d.status) >= 0;
    }).length;
    var ngoMeals = S.state.donations.filter(function (d) {
      return d.matchedNgoId === "n1" && d.status === "delivered";
    }).reduce(function (sum, d) { return sum + d.servings; }, 0);
    var volActive = S.state.donations.filter(function (d) {
      return d.volunteerId === "v1" && ["matched", "pickup", "picked_up"].indexOf(d.status) >= 0;
    }).length;
    var volDelivered = S.state.donations.filter(function (d) {
      return d.volunteerId === "v1" && d.status === "delivered";
    });
    var volMeals = volDelivered.reduce(function (sum, d) { return sum + d.servings; }, 0);

    var copy = {
      donor: {
        eyebrow: "Donor dashboard",
        title: "Good food deserves a second chance.",
        text: "Post today's surplus in under a minute. SharePlate ranks nearby kitchens on distance, current need and freshness — then the closest volunteer takes it from there.",
        actions: '<a class="btn btn-amber" href="#/post">' + icon("plus") + "Post surplus food</a>" +
          '<a class="btn btn-hero-ghost" href="#/donations">View the live board</a>',
        minis: [
          { value: m.partners, label: "partner kitchens" },
          { value: available, label: "donations waiting" },
          { value: "2.5 kg", label: "CO₂e avoided per kg" }
        ],
        disc: "leaf",
        chips: floatingChip("fc-a", "spark", "Match found · 94%", "Asha Community Kitchen · 3.8 km") +
          floatingChip("fc-b", "shield", "Safety checked", "Freshness window tracked") +
          floatingChip("fc-c", "leaf", "2.5 kg CO₂e", "avoided per kg rescued")
      },
      ngo: {
        eyebrow: "Receiver dashboard",
        title: "Every pickup becomes a warm meal.",
        text: available + " donation" + (available === 1 ? " is" : "s are") + " ready for a receiver right now. Accept what your kitchen can use and we will assign the nearest volunteer with a live route.",
        actions: '<a class="btn btn-amber" href="#/donations">' + icon("box") + "Review donations</a>" +
          '<a class="btn btn-hero-ghost" href="#/impact">View impact</a>',
        minis: [
          { value: available, label: "waiting now" },
          { value: ngoAccepted, label: "in your pipeline" },
          { value: S.fmtNum(ngoMeals), label: "meals received" }
        ],
        disc: "heart",
        chips: floatingChip("fc-a", "spark", available + " fresh donations", "Posted in the last hour") +
          floatingChip("fc-b", "home", "120 meals / day", "Kitchen capacity") +
          floatingChip("fc-c", "users", "3 volunteers online", "Nearest route 12 min")
      },
      volunteer: {
        eyebrow: "Volunteer dashboard",
        title: "You are the last mile.",
        text: "One pickup turns a tray of surplus into dinner for dozens of people. Follow the route, complete the safety check and confirm the handover with proof.",
        actions: '<a class="btn btn-amber" href="#/pickups">' + icon("route") + "View pickup route</a>" +
          '<a class="btn btn-hero-ghost" href="#/donations">Donation board</a>',
        minis: [
          { value: volActive, label: "active task" + (volActive === 1 ? "" : "s") },
          { value: volDelivered.length, label: "deliveries completed" },
          { value: S.fmtNum(volMeals), label: "meals moved" }
        ],
        disc: "route",
        chips: floatingChip("fc-a", "route", "Live route", "Pickup → handover") +
          floatingChip("fc-b", "clock", "ETA 12 min", "to Green Leaf Restaurant") +
          floatingChip("fc-c", "camera", "Proof on pickup", "Shared with the donor")
      }
    }[role];

    return '<section class="hero">' +
      '<div class="hero-copy">' +
        '<span class="eyebrow"><span class="eyebrow-dot"></span>' + esc(copy.eyebrow) + "</span>" +
        "<h1>" + esc(copy.title) + "</h1>" +
        "<p>" + esc(copy.text) + "</p>" +
        '<div class="hero-actions">' + copy.actions + "</div>" +
        '<div class="hero-foot">' +
          copy.minis.map(function (x) {
            return '<div class="hero-mini"><strong>' + x.value + "</strong><span>" + x.label + "</span></div>";
          }).join("") +
        "</div>" +
      "</div>" +
      '<aside class="hero-art" aria-hidden="true">' +
        '<div class="orbit second"><span class="orbit-dot"></span></div>' +
        '<div class="orbit"></div>' +
        '<div class="hero-disc">' +
          '<svg viewBox="0 0 24 24"><use href="#i-' + copy.disc + '"></use></svg>' +
          '<span class="disc-badge">' + icon("spark") + "</span>" +
        "</div>" +
        copy.chips +
      "</aside>" +
    "</section>";
  }

  function demoFlowMarkup() {
    var todays = S.state.donations.filter(function (d) {
      return d.donorId === "d1" && S.createdAtToday(d.createdAt);
    });
    var posted = todays.length > 0;
    var accepted = todays.some(function (d) { return ["matched", "pickup", "picked_up", "delivered"].indexOf(d.status) >= 0; });
    var delivered = todays.some(function (d) { return d.status === "delivered"; });

    function step(num, done, title, text, action) {
      return '<div class="demo-step ' + (done ? "done" : "") + '">' +
        '<span class="step-num">' + (done ? icon("check") : num) + "</span>" +
        '<div class="step-body"><strong>' + title + "</strong><p>" + text + "</p>" +
          (done ? '<span class="step-status">' + icon("check") + "Done</span>" : action) +
        "</div>" +
      "</div>";
    }

    return '<section class="demo-flow">' +
      '<div class="demo-head"><div><h3>' + icon("spark") + "Try the full rescue loop</h3>" +
      "<p>Post as the canteen, accept as the kitchen, then deliver as the volunteer. Everything updates live.</p></div>" +
      '<span class="pill pill-outline">' + icon("spark") + "3-step demo</span></div>" +
      '<div class="demo-steps">' +
        step(1, posted, "Post surplus", "Share a tray with photo, servings and a safe window.",
          '<button class="btn btn-ghost btn-sm" data-action="go-page" data-page="post">' + icon("plus") + "Post food</button>") +
        step(2, accepted, "Receiver accepts", "The kitchen reviews freshness, distance and need.",
          '<button class="btn btn-ghost btn-sm" data-action="switch-role" data-role="ngo" data-go="donations">' + icon("shield") + "Open as receiver</button>") +
        step(3, delivered, "Volunteer delivers", "Route, safety checklist and handover code close the loop.",
          '<button class="btn btn-ghost btn-sm" data-action="switch-role" data-role="volunteer" data-go="pickups">' + icon("truck") + "Open as volunteer</button>") +
      "</div>" +
    "</section>";
  }

  function mapLegendReturned() {
    return '<div class="map-legend">' +
      '<span><span class="legend-dot" style="background:#0F6B4F"></span>Donor</span>' +
      '<span><span class="legend-dot" style="background:#D3922C"></span>Receiver</span>' +
      '<span><span class="legend-dot" style="background:#2E6BD6"></span>Volunteer</span>' +
    "</div>";
  }

  /* ------------------------------------------------------------
     Overview
     ------------------------------------------------------------ */
  function activityRow(a) {
    var don = a.donationId ? S.getDonation(a.donationId) : null;
    return '<button class="notif-item" data-action="' + (don ? "open-notification" : "none") + '" data-donation="' + (don ? don.id : "") + '">' +
      '<span class="notif-icon ' + notifTone(a.kind) + '">' + icon(notifIcon(a.kind)) + "</span>" +
      '<span class="notif-main"><span class="notif-text">' + esc(a.text) + "</span>" +
      '<span class="notif-time">' + S.timeAgo(a.at) + "</span></span>" +
    "</button>";
  }

  function donorRows(list) {
    if (!list.length) {
      return '<div class="empty" style="margin:16px 20px">' +
        '<span class="empty-icon">' + icon("box") + "</span>" +
        "<h3>No active surplus posts</h3>" +
        "<p>When you post food it appears here with its freshness window and live handover status.</p>" +
        '<a class="btn btn-primary btn-sm" href="#/post">' + icon("plus") + "Post surplus</a>" +
      "</div>";
    }
    return '<div class="row-list">' + list.map(function (don) {
      var cat = catMeta(don.category);
      return '<div class="row-item clickable" data-action="details" data-id="' + don.id + '">' +
        '<span class="row-media ' + cat.cls + '">' + icon(cat.icon) + "</span>" +
        '<div class="row-body"><div class="row-title"><span>' + esc(don.title) + "</span></div>" +
          '<div class="row-meta"><span>' + don.servings + " meals</span><span>" + S.timeAgo(don.createdAt) + "</span>" +
          (don.matchedNgoId ? "<span>→ " + esc(ngoName(don)) + "</span>" : "") + "</div>" +
        "</div>" +
        '<div class="row-side">' + statusPill(don.status) + "</div>" +
      "</div>";
    }).join("") + "</div>";
  }

  function nearbyReceivers() {
    var origin = S.donors[0].coords;
    var list = S.ngos.slice().sort(function (a, b) {
      return S.coordDistance(origin, a.coords) - S.coordDistance(origin, b.coords);
    });
    return '<div class="row-list">' + list.map(function (n) {
      var km = S.round1(S.coordDistance(origin, n.coords));
      var needTone = n.need === "high" ? "pill-red" : n.need === "medium" ? "pill-amber" : "pill-green";
      return '<div class="row-item">' +
        '<span class="avatar avatar-lg avatar-amber">' + n.short + "</span>" +
        '<div class="row-body"><div class="row-title"><span>' + esc(n.name) + "</span></div>" +
          '<div class="row-meta"><span>' + icon("pin") + km + " km</span><span>" + esc(n.kind) + "</span></div>" +
        "</div>" +
        '<div class="row-side"><span class="pill ' + needTone + '">' + n.need + " need</span></div>" +
      "</div>";
    }).join("") + "</div>";
  }

  function renderOverview() {
    var role = S.persona().role;
    var m = S.metrics();
    var html = '<div class="page">' + heroMarkup();

    if (role === "donor") {
      html += '<div class="stat-grid">' +
        statCard({ icon: "plate", tone: "tone-green", value: m.meals, label: "Meals rescued", sub: "Verified across all partners" }) +
        statCard({ icon: "box", tone: "tone-amber", value: m.weight, suffix: "kg", label: "Food saved", sub: "Estimated from rescued weight" }) +
        statCard({ icon: "leaf", tone: "tone-violet", value: m.co2, suffix: "kg", label: "CO₂e avoided", sub: "2.5 kg per kg of food" }) +
        statCard({ icon: "truck", tone: "tone-blue", value: m.active, label: "Active donations", sub: m.available + " waiting for a receiver" }) +
      "</div>";

      var own = S.state.donations.filter(function (d) {
        return d.donorId === "d1" && d.status !== "delivered";
      }).sort(function (a, b) { return new Date(b.createdAt) - new Date(a.createdAt); });

      html += '<div class="split mt-20">' +
        '<div class="stack">' +
          '<div class="card"><div class="card-head"><div><div class="card-title">Your surplus posts</div>' +
            '<div class="card-sub">Live status for everything you have shared</div></div>' +
            '<a class="btn-link" href="#/donations">View all ' + icon("arrow") + "</a></div>" +
            donorRows(own) +
          "</div>" +
          '<div class="card"><div class="card-head compact"><div class="card-title">Live activity</div>' +
            '<span class="pill pill-green"><span class="live-dot"></span>Live</span></div>' +
            '<div class="row-list">' + S.activity().slice(0, 4).map(activityRow).join("") + "</div>" +
          "</div>" +
        "</div>" +
        '<div class="stack">' +
          '<div class="card"><div class="card-head"><div><div class="card-title">Nearby receivers</div>' +
            '<div class="card-sub">Sorted by distance from your kitchen</div></div></div>' +
            nearbyReceivers() +
            '<div class="card-foot"><span class="hint" style="margin:0">' + icon("info") + " Need levels are set by partner kitchens.</span></div>" +
          "</div>" +
          '<div class="card card-pad"><div class="card-title" style="font-size:15px">How matching works</div>' +
            '<div class="stack-sm" style="margin-top:12px">' +
              '<div class="safety-line">' + icon("pin") + "<span><strong>Distance</strong> — the nearest kitchens rank first.</span></div>" +
              '<div class="safety-line">' + icon("heart") + "<span><strong>Current need</strong> — high-need kitchens get priority.</span></div>" +
              '<div class="safety-line">' + icon("shield") + "<span><strong>Freshness</strong> — the safe window is factored in.</span></div>" +
            "</div>" +
            '<p class="hint" style="margin-top:12px">Prototype score blends distance, need and category fit. The receiver always confirms the pickup.</p>' +
          "</div>" +
        "</div>" +
      "</div>";
    }

    if (role === "ngo") {
      var available = S.state.donations.filter(function (d) { return d.status === "available"; })
        .sort(function (a, b) {
          var sa = S.matchesFor(a).filter(function (x) { return x.ngo.id === "n1"; })[0];
          var sb = S.matchesFor(b).filter(function (x) { return x.ngo.id === "n1"; })[0];
          return (sb ? sb.score : 0) - (sa ? sa.score : 0);
        });
      var pipeline = S.state.donations.filter(function (d) {
        return d.matchedNgoId === "n1" && ["matched", "pickup", "picked_up"].indexOf(d.status) >= 0;
      });
      var received = S.state.donations.filter(function (d) {
        return d.matchedNgoId === "n1" && d.status === "delivered";
      });
      var receivedMeals = received.reduce(function (sum, d) { return sum + d.servings; }, 0);
      var inTransit = pipeline.filter(function (d) { return ["pickup", "picked_up"].indexOf(d.status) >= 0; }).length;
      var committed = pipeline.reduce(function (sum, d) { return sum + d.servings; }, 0);
      var capacity = 120;

      html += '<div class="stat-grid">' +
        statCard({ icon: "box", tone: "tone-amber", value: available.length, label: "Available now", sub: "Ready to accept" }) +
        statCard({ icon: "shield", tone: "tone-green", value: pipeline.length, label: "Accepted by you", sub: "In your pipeline" }) +
        statCard({ icon: "truck", tone: "tone-blue", value: inTransit, label: "In transit", sub: "On the road right now" }) +
        statCard({ icon: "plate", tone: "tone-violet", value: receivedMeals, label: "Meals received", sub: "Delivered to your kitchen" }) +
      "</div>";

      html += '<div class="split mt-20">' +
        '<div class="card"><div class="card-head"><div><div class="card-title">Fresh donations for your kitchen</div>' +
          '<div class="card-sub">Ranked by match score · accept to claim</div></div>' +
          '<a class="btn-link" href="#/donations">Full board ' + icon("arrow") + "</a></div>" +
          '<div class="row-list">' + available.map(function (don) {
            var match = S.matchesFor(don).filter(function (x) { return x.ngo.id === "n1"; })[0] || S.bestMatch(don);
            var cat = catMeta(don.category);
            var f = S.freshness(don);
            return '<div class="row-item">' +
              '<span class="row-media ' + cat.cls + '">' + icon(cat.icon) + "</span>" +
              '<div class="row-body"><div class="row-title"><span>' + esc(don.title) + "</span><span class=\"pill pill-green\">" + match.score + "% match</span></div>" +
                '<div class="row-meta"><span>' + esc(donorName(don)) + "</span><span>" + don.servings + " meals</span><span>" + icon("pin") + match.km + " km</span>" +
                "<span>" + (f.expired ? "Safe window closed" : "Safe " + S.duration(f.left)) + "</span></div>" +
              "</div>" +
              '<div class="row-side">' + (f.expired
                ? '<span class="pill pill-red">Expired</span>'
                : '<button class="btn btn-primary btn-sm" data-action="accept" data-id="' + don.id + '">Accept</button>') +
              "</div>" +
            "</div>";
          }).join("") + "</div>" +
          '<div class="card-foot"><span class="hint" style="margin:0">Accepting assigns the nearest volunteer automatically.</span></div>' +
        "</div>" +
        '<div class="stack">' +
          '<div class="card"><div class="card-head"><div><div class="card-title">Your kitchen today</div>' +
            '<div class="card-sub">Accepted and in transit</div></div></div>' +
            (pipeline.length ? '<div class="row-list">' + pipeline.map(function (don) {
              return '<div class="row-item clickable" data-action="details" data-id="' + don.id + '">' +
                '<span class="row-media media-amber">' + icon("home") + "</span>" +
                '<div class="row-body"><div class="row-title"><span>' + esc(don.title) + "</span></div>" +
                  '<div class="row-meta"><span>' + don.servings + " meals</span><span>" + S.timeAgo(don.createdAt) + "</span>" +
                  (don.status === "matched" ? "<span>Code " + don.handoverCode + "</span>" : "") + "</div>" +
                "</div>" +
                '<div class="row-side">' + statusPill(don.status) + "</div>" +
              "</div>";
            }).join("") + "</div>"
              : '<div class="empty" style="margin:14px 20px"><span class="empty-icon">' + icon("home") + "</span><h3>Nothing accepted yet</h3><p>Claim a donation and it will appear here.</p></div>") +
          "</div>" +
          '<div class="card card-pad"><div class="card-title" style="font-size:15px">Kitchen capacity</div>' +
            '<div class="row-meta" style="margin-top:8px"><span>' + committed + " of " + capacity + " meals committed</span></div>" +
            '<div class="fresh-track" style="margin-top:8px"><div class="fresh-fill" style="width:' + Math.min(100, (committed / capacity) * 100) + '%"></div></div>' +
            '<p class="hint" style="margin-top:10px">Capacity is a prototype setting. In a live system it would update from your daily meal plan.</p>' +
          "</div>" +
        "</div>" +
      "</div>";
    }

    if (role === "volunteer") {
      var tasks = S.state.donations.filter(function (d) {
        return d.volunteerId === "v1" && ["matched", "pickup", "picked_up"].indexOf(d.status) >= 0;
      }).sort(function (a, b) { return new Date(b.createdAt) - new Date(a.createdAt); });
      var done = S.state.donations.filter(function (d) {
        return d.volunteerId === "v1" && d.status === "delivered";
      }).sort(function (a, b) { return new Date(b.deliveredAt) - new Date(a.deliveredAt); });
      var mealsMoved = done.reduce(function (sum, d) { return sum + d.servings; }, 0);
      var kgMoved = done.reduce(function (sum, d) { return sum + d.weightKg; }, 0);

      html += '<div class="stat-grid">' +
        statCard({ icon: "route", tone: "tone-green", value: tasks.length, label: "Active tasks", sub: "Assigned to you" }) +
        statCard({ icon: "check", tone: "tone-amber", value: done.length, label: "Completed pickups", sub: "All time" }) +
        statCard({ icon: "plate", tone: "tone-violet", value: mealsMoved, label: "Meals delivered", sub: "With proof of handover" }) +
        statCard({ icon: "truck", tone: "tone-blue", value: S.round1(kgMoved), suffix: "kg", label: "Food transported", sub: "Rescued from waste" }) +
      "</div>";

      html += '<div class="split mt-20">' +
        '<div class="stack">' + (tasks.length
          ? activeTaskCard(tasks[0])
          : '<div class="card card-pad"><div class="empty" style="border:0;background:transparent"><span class="empty-icon">' + icon("route") + "</span>" +
            "<h3>No active pickups</h3><p>When a receiver accepts a donation, the nearest volunteer is assigned automatically. Your next route will appear here.</p>" +
            '<a class="btn btn-ghost btn-sm" href="#/donations">Browse the board</a></div></div>') +
          (tasks.length > 1 ? otherTasks(tasks.slice(1)) : "") +
        "</div>" +
        '<div class="stack">' +
          '<div class="card"><div class="card-head"><div><div class="card-title">Recent deliveries</div>' +
            '<div class="card-sub">Proof of handover on every drop</div></div></div>' +
            (done.length ? '<div class="row-list">' + done.slice(0, 4).map(function (don) {
              return '<div class="row-item clickable" data-action="details" data-id="' + don.id + '">' +
                '<span class="row-media media-blue">' + icon("check") + "</span>" +
                '<div class="row-body"><div class="row-title"><span>' + esc(don.title) + "</span></div>" +
                  '<div class="row-meta"><span>' + don.servings + " meals</span><span>" + S.timeAgo(don.deliveredAt) + "</span><span>→ " + esc(ngoName(don)) + "</span></div>" +
                "</div>" +
                '<div class="row-side"><span class="pill pill-green">Delivered</span></div>' +
              "</div>";
            }).join("") + "</div>"
              : '<div class="empty" style="margin:14px 20px"><span class="empty-icon">' + icon("truck") + "</span><h3>No deliveries yet</h3><p>Complete your first route to build your record.</p></div>") +
          "</div>" +
          '<div class="card card-pad"><div class="card-title" style="font-size:15px">Before every pickup</div>' +
            '<div class="stack-sm" style="margin-top:12px">' +
              ['Food prepared inside its safe window', 'Held at a safe temperature', 'Covered and hygienically packed', 'No signs of spoilage', 'Allergens confirmed with the donor'].map(function (t) {
                return '<div class="safety-line">' + icon("check") + "<span>" + t + "</span></div>";
              }).join("") +
            "</div>" +
          "</div>" +
        "</div>" +
      "</div>";
    }

    html += demoFlowMarkup() + "</div>";
    return html;
  }

  function otherTasks(tasks) {
    var title = S.persona().role === "volunteer" ? "Other assigned tasks" : "More rescues in progress";
    return '<div class="card mt-20"><div class="card-head compact"><div class="card-title" style="font-size:15px">' + title + '</div></div>' +
      '<div class="row-list">' + tasks.map(function (don) {
        var ngo = S.ngoById(don.matchedNgoId);
        return '<div class="row-item clickable" data-action="details" data-id="' + don.id + '">' +
          '<span class="row-media media-blue">' + icon("route") + "</span>" +
          '<div class="row-body"><div class="row-title"><span>' + esc(don.title) + "</span></div>" +
            '<div class="row-meta"><span>' + esc(donorName(don)) + "</span><span>→ " + esc(ngo ? ngo.name : "") + "</span></div>" +
          "</div>" +
          '<div class="row-side">' + statusPill(don.status) + "</div>" +
        "</div>";
      }).join("") + "</div></div>";
  }

  /* ------------------------------------------------------------
     Active route card (overview + pickups)
     ------------------------------------------------------------ */
  function etaText(don) {
    if (don.status === "matched") {
      var vol = S.volunteerById(don.volunteerId) || S.volunteers[0];
      var donor = S.donorById(don.donorId);
      var km = S.coordDistance(vol.coords, donor.coords);
      return "Ready · about " + S.etaForKm(km) + " min to the donor";
    }
    if (don.status === "pickup") {
      var mins = S.remainingMinutes(don);
      return mins > 0 ? mins + " min to the donor" : "At the donor — confirm pickup";
    }
    if (don.status === "picked_up") {
      var mins2 = S.remainingMinutes(don);
      return mins2 > 0 ? mins2 + " min to the receiver" : "At the receiver — complete handover";
    }
    return "Delivered";
  }

  function activeTaskCard(don) {
    var donor = S.donorById(don.donorId);
    var ngo = don.matchedNgoId ? S.ngoById(don.matchedNgoId) : null;
    var me = S.persona();
    var canAct = me.role === "volunteer" && don.volunteerId === me.id;
    var leg1Done = ["picked_up", "delivered"].indexOf(don.status) >= 0;
    var leg2Done = don.status === "delivered";
    var live = don.status === "pickup" || don.status === "picked_up";

    var actions = "";
    if (canAct && don.status === "matched") {
      actions = '<button class="btn btn-primary" data-action="start-pickup" data-id="' + don.id + '">' + icon("route") + "Start pickup</button>" +
        '<button class="btn btn-ghost" data-action="details" data-id="' + don.id + '">View donation details</button>';
    } else if (canAct && don.status === "pickup") {
      actions = '<button class="btn btn-primary" data-action="pickup-confirm-open" data-id="' + don.id + '">' + icon("camera") + "Confirm pickup</button>" +
        '<button class="btn btn-ghost" data-action="details" data-id="' + don.id + '">View donation details</button>';
    } else if (canAct && don.status === "picked_up") {
      actions = '<button class="btn btn-primary" data-action="delivery-open" data-id="' + don.id + '">' + icon("shield") + "Complete delivery</button>" +
        '<button class="btn btn-ghost" data-action="details" data-id="' + don.id + '">View proof & details</button>';
    } else {
      actions = '<button class="btn btn-ghost" data-action="details" data-id="' + don.id + '">' + icon("info") + "Track donation</button>";
    }

    var note;
    if (canAct) {
      note = don.status === "picked_up"
        ? "Ask " + (ngo ? ngo.name : "the receiver") + " for the 4-digit handover code to close the loop."
        : don.status === "pickup"
          ? "Complete the safety checklist when you reach the donor, then upload a pickup photo."
          : "Complete the five-point safety checklist before you set off. A pickup photo is required.";
    } else if (me.role === "ngo" && don.matchedNgoId === me.id) {
      note = "Your handover code is " + don.handoverCode + ". Share it with the volunteer at delivery to verify the handover.";
    } else if (me.role === "donor" && don.donorId === me.id) {
      note = "Live updates appear here as the assigned volunteer collects and delivers this donation.";
    } else {
      var assigned = S.volunteerById(don.volunteerId);
      note = "Assigned to " + (assigned ? assigned.name : "a volunteer") + ". Status updates appear here in real time.";
    }

    return '<div class="card route-card">' +
      '<div class="route-map">' + mapOuter(don) + "</div>" +
      '<div class="route-panel">' +
        '<div class="route-status">' + statusPill(don.status) +
          (live ? '<span class="pill pill-green"><span class="live-dot"></span>Live</span>' : "") +
        "</div>" +
        '<h3 class="route-title">Pickup from ' + esc(donor ? donor.name : "the donor") + "</h3>" +
        '<p class="route-sub">' + esc(don.title) + " · " + don.servings + " meals · " + don.weightKg + " kg</p>" +
        '<div class="eta-chip">' + icon("clock") + '<span data-eta-donation="' + don.id + '">' + esc(etaText(don)) + "</span></div>" +
        '<div class="route-legs">' +
          '<div class="leg ' + (leg1Done ? "done" : "current") + '"><span class="leg-marker">' + icon(leg1Done ? "check" : "pin") + "</span>" +
            '<div class="leg-body"><div class="leg-label">Collect</div><div class="leg-title">' + esc(donor ? donor.name : "") + "</div>" +
            '<div class="leg-meta">' + esc(don.address) + "</div></div></div>" +
          '<div class="leg ' + (leg2Done ? "done" : don.status === "picked_up" ? "current" : "") + '"><span class="leg-marker">' + icon(leg2Done ? "check" : "home") + "</span>" +
            '<div class="leg-body"><div class="leg-label">Hand over</div><div class="leg-title">' + esc(ngo ? ngo.name : "Receiver") + "</div>" +
            '<div class="leg-meta">' + (don.distanceKm ? don.distanceKm + " km · " : "") + "handover code with receiver</div></div></div>" +
        "</div>" +
        '<div class="route-actions">' + actions + "</div>" +
        '<p class="route-note">' + icon("info") + "<span>" + esc(note) + "</span></p>" +
      "</div>" +
    "</div>";
  }

  /* ------------------------------------------------------------
     Post surplus
     ------------------------------------------------------------ */
  function timeValueFor(date) {
    var h = String(date.getHours()).padStart(2, "0");
    var m = String(date.getMinutes()).padStart(2, "0");
    return h + ":" + m;
  }

  function renderPost() {
    var donor = S.donors[0];
    var categories = S.CATEGORIES.map(function (c) {
      return '<option value="' + c + '">' + c + "</option>";
    }).join("");

    return '<div class="page"><div class="post-grid">' +
      '<form class="card form-card" id="postForm" novalidate>' +
        '<div class="form-section">' +
          '<div class="form-section-title">' + icon("plate") + "What are you sharing?</div>" +
          '<div class="field" id="fTitle">' +
            '<label class="lbl" for="pTitle">Food name <span class="opt">Required</span></label>' +
            '<input class="input" id="pTitle" maxlength="80" placeholder="e.g. Veg pulao & raita" autocomplete="off">' +
            '<div class="field-error">Add a short name for the food.</div>' +
          "</div>" +
          '<div class="field-row">' +
            '<div class="field"><label class="lbl" for="pCategory">Category</label>' +
              '<select class="select" id="pCategory">' + categories + "</select></div>" +
            '<div class="field" id="fServings"><label class="lbl" for="pServings">Servings / meals <span class="opt">Required</span></label>' +
              '<input class="input" id="pServings" type="number" min="1" max="500" inputmode="numeric" value="40">' +
              '<div class="field-error">Enter between 1 and 500 servings.</div></div>' +
          "</div>" +
          '<div class="field"><label class="lbl">Diet</label>' +
            '<div class="segmented" id="dietSegment" role="group" aria-label="Diet type">' +
              '<button type="button" class="seg-btn active" data-diet="veg">Vegetarian</button>' +
              '<button type="button" class="seg-btn" data-diet="nonveg">Non-vegetarian</button>' +
              '<button type="button" class="seg-btn" data-diet="mixed">Mixed</button>' +
            "</div>" +
          "</div>" +
        "</div>" +
        '<div class="form-section">' +
          '<div class="form-section-title">' + icon("clock") + "Freshness & pickup</div>" +
          '<div class="field-row">' +
            '<div class="field" id="fPrepared"><label class="lbl" for="pPrepared">Prepared at <span class="opt">Required</span></label>' +
              '<input class="input" id="pPrepared" type="time">' +
              '<div class="field-error">Choose the time the food was prepared (not in the future).</div></div>' +
            '<div class="field"><label class="lbl" for="pSafe">Safe for</label>' +
              '<select class="select" id="pSafe">' +
                '<option value="2">2 hours</option><option value="4" selected>4 hours</option><option value="6">6 hours</option>' +
              "</select>" +
              '<div class="hint">The freshness bar uses this window.</div>' +
            "</div>" +
          "</div>" +
          '<div class="field" id="fAddress"><label class="lbl" for="pAddress">Pickup address <span class="opt">Required</span></label>' +
            '<input class="input" id="pAddress" maxlength="120" value="' + esc(donor.address) + '">' +
            '<div class="field-error">Add a pickup address the volunteer can find.</div></div>' +
          '<div class="field"><label class="lbl" for="pNotes">Notes for the receiver <span class="opt">Optional</span></label>' +
            '<textarea class="textarea" id="pNotes" maxlength="300" placeholder="Allergens, packaging or handling notes"></textarea>' +
            '<div class="hint">Allergen and handling details help the receiver plan safely.</div></div>' +
        "</div>" +
        '<div class="form-section">' +
          '<div class="form-section-title">' + icon("camera") + "Photo & confirmation</div>" +
          '<div class="field"><label class="lbl">Food photo <span class="opt">Optional</span></label>' +
            '<div class="upload" id="uploadZone" role="button" tabindex="0">' +
              icon("upload") + "<strong>Upload a photo</strong><span>JPG or PNG · helps the receiver verify packaging</span>" +
              '<input type="file" id="photoInput" accept="image/*">' +
            "</div>" +
            '<div id="photoPreview"></div>' +
          "</div>" +
          '<label class="check"><input type="checkbox" id="pConfirm"><span>I confirm the food is freshly prepared, covered and safe to transport.</span></label>' +
          '<div class="field-error" id="confirmError">Please confirm the food-safety statement.</div>' +
        "</div>" +
        '<div class="form-actions">' +
          '<span class="hint" style="margin:0">A nearby receiver is matched automatically.</span>' +
          '<button class="btn btn-primary" type="submit" id="postSubmit">' + icon("spark") + "Post & find a match</button>" +
        "</div>" +
      "</form>" +
      '<aside class="sticky-col">' +
        '<div class="match-preview">' +
          '<span class="eyebrow-sm">' + icon("spark") + "Live match preview</span>" +
          '<div class="estimate-row">' +
            '<div class="estimate"><strong id="previewMeals">40</strong><span>meals</span></div>' +
            '<div class="estimate"><strong id="previewWeight">11.2</strong><span>kg estimated</span></div>' +
          "</div>" +
          '<div class="match-ngo">' +
            '<span class="avatar avatar-amber">AK</span>' +
            '<div class="row-body"><div class="row-title" id="previewNgo">Asha Community Kitchen</div>' +
              '<div class="match-meta"><span>' + icon("pin") + '<span id="previewKm">3.0 km</span></span>' +
              '<span>' + icon("clock") + '<span id="previewEta">14 min</span></span></div>' +
            "</div>" +
            '<div class="match-score"><strong id="previewScore">96</strong><span>match</span></div>' +
          "</div>" +
          '<p class="match-note">' + icon("info") + "<span>Score blends distance, current need and category fit. A receiver still confirms the pickup.</span></p>" +
        "</div>" +
        '<div class="card tips-card">' +
          "<h3>" + icon("shield") + "Food-safety essentials</h3>" +
          '<ul class="tips-list">' +
            "<li>Keep hot food above <strong>60°C</strong> or chilled food below <strong>5°C</strong>.</li>" +
            "<li>Pack in clean, covered containers and label allergens.</li>" +
            "<li>Post at least <strong>2 hours</strong> before your safe window closes.</li>" +
            "<li>Confirm the five-point checklist before the volunteer leaves.</li>" +
          "</ul>" +
        "</div>" +
      "</aside>" +
    "</div></div>";
  }

  function initPost() {
    var form = document.getElementById("postForm");
    if (!form) return;
    var diet = "veg";
    var prepared = document.getElementById("pPrepared");
    prepared.value = timeValueFor(new Date(Date.now() - 45 * S.MIN));
    updatePreview();

    form.addEventListener("input", function (e) {
      if (["pServings", "pCategory", "pTitle"].indexOf(e.target.id) >= 0) updatePreview();
      var field = e.target.closest(".field");
      if (field) field.classList.remove("invalid");
      if (e.target.id === "pConfirm") document.getElementById("confirmError").style.display = "none";
    });

    var seg = document.getElementById("dietSegment");
    seg.addEventListener("click", function (e) {
      var btn = e.target.closest(".seg-btn");
      if (!btn) return;
      diet = btn.getAttribute("data-diet");
      $$(".seg-btn", seg).forEach(function (b) { b.classList.toggle("active", b === btn); });
    });

    var zone = document.getElementById("uploadZone");
    var input = document.getElementById("photoInput");
    function openPicker() { input.click(); }
    zone.addEventListener("click", openPicker);
    zone.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openPicker(); }
    });
    ["dragenter", "dragover"].forEach(function (ev) {
      zone.addEventListener(ev, function (e) { e.preventDefault(); zone.classList.add("dragover"); });
    });
    ["dragleave", "drop"].forEach(function (ev) {
      zone.addEventListener(ev, function (e) { e.preventDefault(); zone.classList.remove("dragover"); });
    });
    zone.addEventListener("drop", function (e) {
      var file = e.dataTransfer.files && e.dataTransfer.files[0];
      if (file) handlePostPhoto(file);
    });
    input.addEventListener("change", function () {
      if (input.files && input.files[0]) handlePostPhoto(input.files[0]);
    });

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      submitPost(form, diet);
    });

    function updatePreview() {
      var servings = Math.max(0, Math.min(500, parseInt(document.getElementById("pServings").value, 10) || 0));
      document.getElementById("previewMeals").textContent = servings;
      document.getElementById("previewWeight").textContent = S.round1(servings * 0.28);
      var category = document.getElementById("pCategory").value;
      var best = S.bestMatch({ donorId: "d1", category: category, coords: S.donors[0].coords });
      document.getElementById("previewNgo").textContent = best.ngo.name;
      document.getElementById("previewKm").textContent = best.km + " km";
      document.getElementById("previewEta").textContent = best.etaMin + " min";
      document.getElementById("previewScore").textContent = best.score;
    }

    function handlePostPhoto(file) {
      readImage(file).then(function (dataUrl) {
        state.postPhoto = dataUrl;
        renderPostPhoto(dataUrl);
      }).catch(function (err) { toast(err.message, "error"); });
    }

    function renderPostPhoto(dataUrl) {
      var preview = document.getElementById("photoPreview");
      preview.innerHTML = '<div class="upload-preview"><img src="' + dataUrl + '" alt="Selected food photo">' +
        '<button type="button" class="upload-remove" id="photoRemove" aria-label="Remove photo">' + icon("close") + "</button></div>";
      var remove = document.getElementById("photoRemove");
      remove.addEventListener("click", function (e) {
        e.stopPropagation();
        state.postPhoto = null;
        preview.innerHTML = "";
        input.value = "";
      });
    }
  }

  function markFieldInvalid(id) {
    var field = document.getElementById(id);
    if (!field) return;
    var wrap = field.closest(".field");
    if (wrap) wrap.classList.add("invalid");
  }

  function submitPost(form, diet) {
    var titleEl = document.getElementById("pTitle");
    var servingsEl = document.getElementById("pServings");
    var addressEl = document.getElementById("pAddress");
    var preparedEl = document.getElementById("pPrepared");
    var confirmEl = document.getElementById("pConfirm");
    var confirmError = document.getElementById("confirmError");
    $$(".field.invalid", form).forEach(function (f) { f.classList.remove("invalid"); });
    confirmError.style.display = "none";

    var title = titleEl.value.trim();
    var servings = parseInt(servingsEl.value, 10);
    var address = addressEl.value.trim();
    var ok = true;

    if (!title) { markFieldInvalid("fTitle"); ok = false; }
    if (!servings || servings < 1 || servings > 500) { markFieldInvalid("fServings"); ok = false; }
    if (!address) { markFieldInvalid("fAddress"); ok = false; }

    var preparedISO = null;
    if (!preparedEl.value) {
      markFieldInvalid("fPrepared"); ok = false;
    } else {
      var parts = preparedEl.value.split(":");
      var d = new Date();
      d.setSeconds(0, 0);
      d.setHours(Number(parts[0]), Number(parts[1]), 0, 0);
      if (d.getTime() > Date.now() + 5 * 60 * 1000) {
        markFieldInvalid("fPrepared"); ok = false;
      } else {
        preparedISO = d.toISOString();
      }
    }

    if (!confirmEl.checked) {
      confirmError.style.display = "block";
      ok = false;
    }

    if (!ok) {
      toast("Please complete the highlighted fields.", "error");
      return;
    }

    var don = S.createDonation({
      title: title,
      category: document.getElementById("pCategory").value,
      servings: servings,
      diet: diet,
      preparedAt: preparedISO,
      safeHours: Number(document.getElementById("pSafe").value),
      address: address,
      notes: document.getElementById("pNotes").value.trim(),
      photo: state.postPhoto
    });

    state.postPhoto = null;
    resetPostForm();
    openMatching(don);
  }

  function resetPostForm() {
    var form = document.getElementById("postForm");
    if (!form) return;
    form.reset();
    document.getElementById("pPrepared").value = timeValueFor(new Date(Date.now() - 45 * S.MIN));
    document.getElementById("photoInput").value = "";
    document.getElementById("photoPreview").innerHTML = "";
    document.getElementById("confirmError").style.display = "none";
    $$(".field.invalid").forEach(function (f) { f.classList.remove("invalid"); });
    $$(".seg-btn", document.getElementById("dietSegment")).forEach(function (b, i) {
      b.classList.toggle("active", i === 0);
    });
    document.getElementById("previewMeals").textContent = "40";
    document.getElementById("previewWeight").textContent = "11.2";
    updatePreviewSafe();
  }

  function updatePreviewSafe() {
    var best = S.bestMatch({ donorId: "d1", category: document.getElementById("pCategory").value, coords: S.donors[0].coords });
    document.getElementById("previewNgo").textContent = best.ngo.name;
    document.getElementById("previewKm").textContent = best.km + " km";
    document.getElementById("previewEta").textContent = best.etaMin + " min";
    document.getElementById("previewScore").textContent = best.score;
  }

  /* ------------------------------------------------------------
     Donation board
     ------------------------------------------------------------ */
  function filteredDonations() {
    var list = S.state.donations.slice();
    if (state.filter !== "all") list = list.filter(function (d) { return d.status === state.filter; });
    if (state.search) {
      var q = state.search.toLowerCase();
      list = list.filter(function (d) {
        return (d.title + " " + donorName(d) + " " + ngoName(d) + " " + d.id + " " + d.category).toLowerCase().indexOf(q) >= 0;
      });
    }
    return list.sort(function (a, b) {
      var aDelivered = a.status === "delivered" ? 1 : 0;
      var bDelivered = b.status === "delivered" ? 1 : 0;
      if (aDelivered !== bDelivered) return aDelivered - bDelivered;
      return new Date(b.createdAt) - new Date(a.createdAt);
    });
  }

  function countsByStatus() {
    var counts = { all: S.state.donations.length };
    ["available", "matched", "pickup", "picked_up", "delivered"].forEach(function (k) { counts[k] = 0; });
    S.state.donations.forEach(function (d) {
      if (counts[d.status] !== undefined) counts[d.status] += 1;
    });
    return counts;
  }

  function cardActionMarkup(don) {
    var role = S.persona().role;
    var me = S.persona();
    if (don.status === "available") {
      if (role === "ngo") {
        if (S.freshness(don).expired) return '<button class="btn btn-ghost btn-sm" disabled>Safe window closed</button>';
        return '<button class="btn btn-primary btn-sm" data-action="accept" data-id="' + don.id + '">' + icon("check") + "Accept donation</button>";
      }
      return '<button class="btn btn-soft btn-sm" data-action="continue-ngo" data-id="' + don.id + '">' + icon("shield") + "Accept as receiver</button>";
    }
    if (don.status === "matched") {
      if (role === "volunteer" && don.volunteerId === me.id) {
        return '<button class="btn btn-primary btn-sm" data-action="start-pickup" data-id="' + don.id + '">' + icon("route") + "Start pickup</button>";
      }
      return '<button class="btn btn-ghost btn-sm" data-action="details" data-id="' + don.id + '">' + icon("info") + "Track handover</button>";
    }
    if (don.status === "pickup") {
      if (role === "volunteer" && don.volunteerId === me.id) {
        return '<button class="btn btn-primary btn-sm" data-action="pickup-confirm-open" data-id="' + don.id + '">' + icon("camera") + "Confirm pickup</button>";
      }
      return '<button class="btn btn-ghost btn-sm" data-action="details" data-id="' + don.id + '">' + icon("truck") + "Track handover</button>";
    }
    if (don.status === "picked_up") {
      if (role === "volunteer" && don.volunteerId === me.id) {
        return '<button class="btn btn-primary btn-sm" data-action="delivery-open" data-id="' + don.id + '">' + icon("shield") + "Complete delivery</button>";
      }
      return '<button class="btn btn-ghost btn-sm" data-action="details" data-id="' + don.id + '">' + icon("camera") + "View proof</button>";
    }
    return '<button class="btn btn-ghost btn-sm" data-action="details" data-id="' + don.id + '">' + icon("check") + "View proof</button>";
  }

  function cardHint(don) {
    var role = S.persona().role;
    var donor = S.donorById(don.donorId);
    if (don.status === "available" && S.freshness(don).expired) {
      return icon("alert") + " Safe window has closed — this donation is not matchable.";
    }
    if (don.status === "matched" && role === "ngo" && don.matchedNgoId === S.persona().id) {
      return icon("shield") + " Handover code <strong>" + don.handoverCode + "</strong> · share at delivery";
    }
    if (don.status === "matched" || don.status === "pickup") {
      var vol = S.volunteerById(don.volunteerId);
      return icon("truck") + " " + (vol ? vol.name : "Volunteer") + (don.status === "pickup" ? " is on the way" : " will collect") + (don.matchedNgoId ? " · " + esc(ngoName(don)) : "");
    }
    if (don.status === "picked_up") {
      return icon("camera") + " Picked up " + S.timeAgo(don.pickedAt) + " · proof shared with " + esc(donor ? donor.name : "the donor");
    }
    if (don.status === "delivered") {
      return icon("check") + " Delivered " + S.timeAgo(don.deliveredAt) + " · proof on record";
    }
    return "";
  }

  function donationCard(don) {
    var cat = catMeta(don.category);
    var donor = S.donorById(don.donorId);
    var best = don.status === "available" ? S.bestMatch(don) : null;
    var score = don.matchScore || (best ? best.score : null);
    var photo = don.proofPhoto || don.photo;
    var withPhoto = !!photo;
    var photoAlt = don.proofPhoto
      ? "Proof of delivery for " + don.title
      : "Food photo for " + don.title;
    var meta = '<span class="meta">' + icon("plate") + don.servings + " meals</span>" +
      '<span class="meta">' + icon("box") + don.weightKg + " kg</span>" +
      '<span class="meta">' + icon("leaf") + dietLabel(don.diet) + "</span>";
    if (don.distanceKm) meta += '<span class="meta">' + icon("pin") + don.distanceKm + " km</span>";

    var primary = cardActionMarkup(don);
    var isDetails = primary.indexOf('data-action="details"') >= 0;
    var hint = cardHint(don);

    return '<article class="donation-card" data-id="' + don.id + '">' +
      '<div class="card-media ' + cat.cls + (withPhoto ? " has-photo" : "") + '">' +
        (withPhoto ? '<img class="card-photo" src="' + photo + '" alt="' + esc(photoAlt) + '">' : "") +
        '<span class="media-status">' + statusPill(don.status) + "</span>" +
        (score ? '<span class="media-score">' + icon("spark") + score + "%</span>" : "") +
        icon(cat.icon, "media-icon") +
        '<span class="media-label">' + esc(don.category) + "</span>" +
      "</div>" +
      '<div class="donation-body">' +
        '<div class="donation-kicker">' + icon("pin") + "<span>" + esc(donor ? donor.name : "") + " · " + S.timeAgo(don.createdAt) + "</span></div>" +
        '<h3 class="donation-title">' + esc(don.title) + "</h3>" +
        '<div class="meta-chips">' + meta + "</div>" +
        (["available", "matched", "pickup"].indexOf(don.status) >= 0
          ? freshnessMarkup(don)
          : '<div class="card-hint" style="margin-top:12px">' + hint + "</div>") +
        (hint && ["available", "matched", "pickup"].indexOf(don.status) >= 0 ? '<div class="card-hint">' + hint + "</div>" : "") +
        '<div class="donation-actions">' + primary +
          (isDetails ? "" : '<button class="btn btn-quiet btn-sm" data-action="details" data-id="' + don.id + '">Details</button>') +
        "</div>" +
      "</div>" +
    "</article>";
  }

  function boardCardsMarkup() {
    var list = filteredDonations();
    if (!list.length) {
      return '<div class="empty" style="grid-column:1/-1"><span class="empty-icon">' + icon("search") + "</span>" +
        "<h3>No donations match this view</h3><p>Try another status filter or clear the search.</p>" +
        '<button class="btn btn-ghost btn-sm" data-action="clear-filters">Clear filters</button></div>';
    }
    return list.map(donationCard).join("");
  }

  function renderBoardGrid() {
    var grid = document.getElementById("boardGrid");
    if (grid) grid.innerHTML = boardCardsMarkup();
  }

  function boardRoleNote() {
    var role = S.persona().role;
    if (role === "ngo") return "Accept a fresh donation to claim it. The nearest volunteer is assigned automatically and a handover code is generated.";
    if (role === "volunteer") return "Matched donations assigned to you appear on the Pickups page. Use the board to check status and proof.";
    return "Post surplus, then switch to Receiver to accept it and to Volunteer to complete the route.";
  }

  function renderDonations() {
    var counts = countsByStatus();
    var filters = [
      { key: "all", label: "All" },
      { key: "available", label: "Available" },
      { key: "matched", label: "Accepted" },
      { key: "pickup", label: "En route" },
      { key: "picked_up", label: "Picked up" },
      { key: "delivered", label: "Delivered" }
    ];
    return '<div class="page">' +
      '<div class="board-note"><span class="role-tag">' + esc(S.persona().label) + "</span><span>" + esc(boardRoleNote()) + "</span></div>" +
      '<div class="board-toolbar">' +
        '<div class="filters" role="group" aria-label="Filter donations">' +
          filters.map(function (f) {
            return '<button class="chip ' + (state.filter === f.key ? "active" : "") + '" data-action="filter" data-filter="' + f.key + '">' +
              f.label + '<span class="chip-count">' + (counts[f.key] || 0) + "</span></button>";
          }).join("") +
        "</div>" +
        '<label class="search-box">' + icon("search") +
          '<input type="search" id="boardSearch" placeholder="Search food, donor or ID" value="' + esc(state.search) + '" aria-label="Search donations">' +
        "</label>" +
      "</div>" +
      '<div class="board-grid" id="boardGrid">' + boardCardsMarkup() + "</div>" +
    "</div>";
  }

  /* ------------------------------------------------------------
     Pickups
     ------------------------------------------------------------ */
  function renderPickups() {
    var me = S.persona();
    var isVolunteer = me.role === "volunteer";
    var activeTasks = S.state.donations.filter(function (d) {
      return ["matched", "pickup", "picked_up"].indexOf(d.status) >= 0;
    });
    var tasks = (isVolunteer ? activeTasks.filter(function (d) { return d.volunteerId === "v1"; }) : activeTasks)
      .sort(function (a, b) { return new Date(b.createdAt) - new Date(a.createdAt); });
    var done = S.state.donations.filter(function (d) {
      if (d.status !== "delivered") return false;
      return isVolunteer ? d.volunteerId === "v1" : true;
    }).sort(function (a, b) { return new Date(b.deliveredAt) - new Date(a.deliveredAt); });

    var header = '<div class="section-head" style="margin-top:0"><div><div class="section-title">' +
      (isVolunteer ? "Your routes" : "Live pickups") + "</div>" +
      '<div class="section-sub">' + (isVolunteer ? "Pickup, safety check and verified handover" : "Track every rescue in progress across the network") + "</div></div>" +
      '<span class="role-tag">' + esc(me.label) + "</span></div>";

    if (!tasks.length) {
      return '<div class="page">' + header +
        '<div class="card card-pad"><div class="empty" style="border:0;background:transparent">' +
          '<span class="empty-icon">' + icon("route") + "</span>" +
          "<h3>No active pickups right now</h3>" +
          "<p>When a receiver accepts a donation, the nearest volunteer is assigned automatically. Activity will appear here.</p>" +
          '<a class="btn btn-primary btn-sm" href="#/donations">Browse the donation board</a>' +
        "</div></div>" +
        (done.length ? recentDeliveries(done) : "") +
      "</div>";
    }

    return '<div class="page">' + header +
      activeTaskCard(tasks[0]) +
      (tasks.length > 1 ? otherTasks(tasks.slice(1)) : "") +
      '<div class="split mt-20">' +
        '<div class="card card-pad"><div class="card-title" style="font-size:15px">Route protocol</div>' +
          '<div class="stack-sm" style="margin-top:12px">' +
            '<div class="safety-line">' + icon("shield") + "<span>Complete the five-point safety checklist before setting off.</span></div>" +
            '<div class="safety-line">' + icon("camera") + "<span>Upload a pickup photo — it is shared with the donor instantly.</span></div>" +
            '<div class="safety-line">' + icon("pin") + "<span>Use the receiver's 4-digit handover code to confirm delivery.</span></div>" +
            '<div class="safety-line">' + icon("clock") + "<span>ETAs in this prototype are simulated so you can follow the route live.</span></div>" +
          "</div>" +
        "</div>" +
        recentDeliveries(done) +
      "</div>" +
    "</div>";
  }

  function recentDeliveries(done) {
    if (!done.length) {
      return '<div class="card card-pad"><div class="empty" style="border:0;background:transparent;padding:18px"><span class="empty-icon">' + icon("truck") + "</span><h3>No deliveries yet</h3><p>Verified handovers will be listed here.</p></div></div>";
    }
    return '<div class="card"><div class="card-head compact"><div><div class="card-title" style="font-size:15px">Recent deliveries</div>' +
      '<div class="card-sub">Verified handovers</div></div></div>' +
      '<div class="row-list">' + done.slice(0, 4).map(function (don) {
        return '<div class="row-item clickable" data-action="details" data-id="' + don.id + '">' +
          '<span class="row-media media-blue">' + icon("check") + "</span>" +
          '<div class="row-body"><div class="row-title"><span>' + esc(don.title) + "</span></div>" +
            '<div class="row-meta"><span>' + don.servings + " meals</span><span>" + S.timeAgo(don.deliveredAt) + "</span><span>" + esc(ngoName(don)) + "</span></div>" +
          "</div>" +
          '<div class="row-side"><span class="pill pill-green">Delivered</span></div>' +
        "</div>";
      }).join("") + "</div></div>";
  }

  /* ------------------------------------------------------------
     Impact
     ------------------------------------------------------------ */
  function renderImpact() {
    var m = S.metrics();
    var week = S.weekSeries();
    var cats = S.categorySeries();
    var leaders = S.leaderboard();
    var goal = 1200;
    var pct = Math.round((m.weekMeals / goal) * 100);
    var recent = S.state.donations.filter(function (d) { return d.status === "delivered"; })
      .sort(function (a, b) { return new Date(b.deliveredAt) - new Date(a.deliveredAt); })
      .slice(0, 4);

    return '<div class="page">' +
      '<div class="kpi-grid">' +
        kpiCard({ icon: "plate", tone: "tone-green", value: m.meals, label: "Meals rescued", sub: "All-time verified deliveries" }) +
        kpiCard({ icon: "box", tone: "tone-amber", value: m.weight, suffix: "kg", label: "Food saved", sub: "Estimated from rescued weight" }) +
        kpiCard({ icon: "leaf", tone: "tone-violet", value: m.co2, suffix: "kg", label: "CO₂e avoided", sub: "At 2.5 kg per kg rescued" }) +
        kpiCard({ icon: "truck", tone: "tone-blue", value: m.deliveredCount, label: "Deliveries completed", sub: "Each with proof of handover" }) +
      "</div>" +
      '<div class="impact-grid">' +
        '<div class="card chart-card"><div class="chart-head"><div><h3>Meals rescued — last 7 days</h3>' +
          '<p>Verified servings delivered to partner kitchens</p></div>' +
          '<span class="chart-badge">' + icon("calendar") + "This week</span></div>" +
          '<div class="chart" id="weekChart"></div>' +
        "</div>" +
        '<div class="goal-card">' +
          "<h3>Weekly goal</h3><p>Meals rescued across the network</p>" +
          '<div class="goal-ring" id="goalRing">' + Charts.ring(Math.min(100, pct)) +
            '<div class="goal-ring-center"><div><strong>' + pct + '%</strong><span>of goal</span></div></div>' +
          "</div>" +
          '<div class="goal-meta"><strong>' + S.fmtNum(m.weekMeals) + "</strong> of " + S.fmtNum(goal) + " meals this week</div>" +
        "</div>" +
      "</div>" +
      '<div class="impact-row">' +
        '<div class="card chart-card"><div class="chart-head"><div><h3>By food category</h3>' +
          '<p>All-time rescued servings</p></div><span class="chart-badge">All-time</span></div>' +
          '<div id="catChart"></div></div>' +
        '<div class="card chart-card"><div class="chart-head"><div><h3>Top donors</h3>' +
          '<p>Servings rescued all-time</p></div><span class="chart-badge">' + icon("users") + leaders.length + " donors</span></div>" +
          '<div class="leaderboard">' + leaders.slice(0, 4).map(function (p, i) {
            var max = leaders[0] ? leaders[0].meals : 1;
            return '<div class="lb-row">' +
              '<span class="lb-rank">' + (i + 1) + "</span>" +
              avatarMarkup(p.name, p.short) +
              '<div class="lb-name"><strong>' + esc(p.name) + (p.you ? " · You" : "") + "</strong>" +
                '<div class="lb-bar"><span style="width:' + Math.max(6, Math.round((p.meals / max) * 100)) + '%"></span></div></div>' +
              '<div class="lb-meals">' + S.fmtNum(p.meals) + "<small>meals</small></div>" +
            "</div>";
          }).join("") + "</div></div>" +
        '<div class="card chart-card"><div class="chart-head"><div><h3>Proof of delivery</h3>' +
          '<p>Recent completed handovers</p></div><span class="chart-badge">' + icon("camera") + recent.length + "</span></div>" +
          '<div class="gallery">' + (recent.length ? recent.map(function (don) {
            var cat = catMeta(don.category);
            return '<button class="gallery-item ' + cat.cls + '" data-action="details" data-id="' + don.id + '" aria-label="View ' + esc(don.title) + ' proof">' +
              (don.proofPhoto
                ? '<img src="' + don.proofPhoto + '" alt="Proof of delivery for ' + esc(don.title) + '">'
                : icon(cat.icon, "gallery-icon")) +
              '<span class="gallery-cap"><strong>' + esc(don.title) + "</strong><span>" + esc(ngoName(don)) + " · " + S.timeAgo(don.deliveredAt) + "</span></span>" +
            "</button>";
          }).join("") : '<div class="gallery-empty">No proofs yet — complete a delivery to add one.</div>') +
          "</div>" +
        "</div>" +
      "</div>" +
      '<p class="impact-note">' + icon("info") +
        "<span>Prototype figures are computed from demo data. CO₂e avoided is estimated at 2.5 kg per kg of food rescued; meals are counted as served portions.</span></p>" +
    "</div>";
  }

  /* ------------------------------------------------------------
     Rendering
     ------------------------------------------------------------ */
  function stopMaps() {
    $$("[data-map-donation]").forEach(function (el) {
      if (el.__mapStop) { el.__mapStop(); el.__mapStop = null; }
    });
  }

  function initMaps() {
    $$("[data-map-donation]").forEach(function (el) {
      var don = S.getDonation(el.getAttribute("data-map-donation"));
      if (!don) return;
      var donor = S.donorById(don.donorId);
      var match = don.matchedNgoId ? null : S.bestMatch(don);
      var ngo = don.matchedNgoId ? S.ngoById(don.matchedNgoId) : match ? match.ngo : null;
      var vol = don.volunteerId ? S.volunteerById(don.volunteerId) : null;
      var stage = don.status === "available" ? "available" : don.status;
      RouteMap.render(el, {
        donor: donor,
        ngo: ngo,
        volunteer: vol,
        stage: stage,
        getProgress: function () { return S.legProgress(don); }
      });
    });
  }

  function render() {
    var page = pageFromHash();
    stopMaps();
    closeDropdowns();
    state.page = page;
    renderChrome(page);

    var main = document.getElementById("main");
    if (page === "overview") main.innerHTML = renderOverview();
    else if (page === "post") main.innerHTML = renderPost();
    else if (page === "donations") main.innerHTML = renderDonations();
    else if (page === "pickups") main.innerHTML = renderPickups();
    else if (page === "impact") main.innerHTML = renderImpact();

    if (page === "post") initPost();
    if (page === "impact") {
      Charts.bars(document.getElementById("weekChart"), S.weekSeries());
      var cats = S.categorySeries();
      if (cats.length) Charts.donut(document.getElementById("catChart"), cats);
    }

    initMaps();
    animateCounters();

    if (state.lastRenderPage !== page) {
      window.scrollTo({ top: 0, behavior: "auto" });
      state.lastRenderPage = page;
    }
  }

  /* ------------------------------------------------------------
     Modal infrastructure
     ------------------------------------------------------------ */
  function openModal(html, wide) {
    modal.classList.toggle("modal-wide", !!wide);
    modalShell.innerHTML = html;
    if (!modal.open) modal.showModal();
  }

  function closeModal() {
    if (modal.open) modal.close();
  }

  modal.addEventListener("close", function () {
    state.matchTimers.forEach(function (t) { clearTimeout(t); });
    state.matchTimers = [];
    modalShell.innerHTML = "";
    state.modalPhoto = null;
  });

  modal.addEventListener("click", function (e) {
    if (e.target === modal) closeModal();
  });

  function modalHead(kicker, title, extra) {
    return '<div class="modal-head"><div class="modal-title-wrap">' +
      (kicker ? '<div class="modal-kicker">' + kicker + "</div>" : "") +
      '<h2 class="modal-title" id="modalTitle">' + title + "</h2>" +
      (extra || "") +
      '</div><button class="modal-close" data-action="close-modal" aria-label="Close dialog">' + icon("close") + "</button></div>";
  }

  /* ------------------------------------------------------------
     Matching flow
     ------------------------------------------------------------ */
  function openMatching(don) {
    var best = S.bestMatch(don);
    openModal(
      modalHead("Smart matching", "Finding the nearest receiver", "") +
      '<div class="modal-body"><div class="scanner">' +
        '<div class="scan-ring">' + icon("spark") + "</div>" +
        "<h3>Scanning nearby kitchens…</h3>" +
        "<p>" + don.servings + " " + esc(don.category.toLowerCase()) + " · freshness window active</p>" +
        '<div class="scan-steps">' +
          '<div class="scan-step" data-step="0"><span class="dot">' + icon("check") + "</span>Checking partner kitchens nearby</div>" +
          '<div class="scan-step" data-step="1"><span class="dot">' + icon("check") + "</span>Scoring distance, need and category fit</div>" +
          '<div class="scan-step" data-step="2"><span class="dot">' + icon("check") + "</span>Selecting the best receiver</div>" +
        "</div>" +
        '<div class="scan-bar"><span id="scanBar"></span></div>' +
      "</div></div>"
    );

    function setStep(n) {
      var steps = $$(".scan-step");
      steps.forEach(function (el, i) {
        el.classList.toggle("active", i === n);
        el.classList.toggle("done", i < n);
      });
      var bar = document.getElementById("scanBar");
      if (bar) bar.style.width = [18, 55, 86][Math.min(n, 2)] + "%";
    }

    setStep(0);
    state.matchTimers.push(setTimeout(function () { if (modal.open) setStep(1); }, 520));
    state.matchTimers.push(setTimeout(function () { if (modal.open) setStep(2); }, 1050));
    state.matchTimers.push(setTimeout(function () {
      if (!modal.open) return;
      var bar = document.getElementById("scanBar");
      if (bar) bar.style.width = "100%";
      state.matchTimers.push(setTimeout(function () {
        if (modal.open) showMatchResult(don, best);
      }, 320));
    }, 1550));
  }

  function showMatchResult(don, best) {
    var vol = S.nearestVolunteer(don.coords);
    openModal(
      modalHead("Match complete", "Your surplus has a destination", "") +
      '<div class="modal-body">' +
        '<div class="success-hero"><div class="big-check">' + icon("check") + "</div>" +
          "<h3>" + esc(best.ngo.name) + " is the best match</h3>" +
          "<p>We notified the kitchen. Once they accept, " + esc(vol.name) + " will collect the food from you and deliver it with proof.</p>" +
        "</div>" +
        '<div class="match-card">' +
          avatarMarkup(best.ngo.name, best.ngo.short, "avatar-amber avatar-lg") +
          '<div class="row-body"><div class="row-title">' + esc(best.ngo.name) + "</div>" +
            '<div class="match-card-meta"><span>' + icon("pin") + best.km + " km away</span>" +
            "<span>" + icon("clock") + best.etaMin + " min route</span>" +
            "<span>" + icon("heart") + best.ngo.need + " need</span></div>" +
          "</div>" +
          '<div class="match-score"><strong>' + best.score + "</strong><span>match</span></div>" +
        "</div>" +
        '<div class="modal-section"><div class="fact-list">' +
          '<div class="fact"><dt>Donation</dt><dd>' + esc(don.title) + " · " + don.id + "</dd></div>" +
          '<div class="fact"><dt>Servings</dt><dd>' + don.servings + " meals · " + don.weightKg + " kg</dd></div>" +
          '<div class="fact"><dt>Pickup</dt><dd>' + esc(don.address) + "</dd></div>" +
          '<div class="fact"><dt>Station</dt><dd><span class="pill pill-amber">Waiting for receiver</span></dd></div>' +
        "</div></div>" +
      "</div>" +
      '<div class="modal-foot">' +
        '<button class="btn btn-ghost" data-action="close-modal">Back to dashboard</button>' +
        '<button class="btn btn-primary" data-action="continue-ngo" data-id="' + don.id + '">Continue as receiver ' + icon("arrow") + "</button>" +
      "</div>",
      true
    );
  }

  /* ------------------------------------------------------------
     Accept / pickup / delivery modals
     ------------------------------------------------------------ */
  function openAccept(id) {
    var don = S.getDonation(id);
    if (!don) return;
    if (don.status !== "available") { toast("This donation has already been accepted.", "error"); return; }
    if (S.freshness(don).expired) { toast("The safe window for this food has closed.", "error"); return; }
    var me = S.persona();
    var match = S.matchesFor(don).filter(function (m) { return m.ngo.id === me.id; })[0] || S.bestMatch(don);
    var vol = S.nearestVolunteer(don.coords);

    openModal(
      modalHead("Receiver action", "Accept this donation?", "") +
      '<div class="modal-body">' +
        '<p class="modal-intro">Accepting claims the donation for your kitchen and assigns the nearest volunteer. A handover code is generated for delivery.</p>' +
        '<div class="modal-summary">' +
          '<span class="row-media ' + catMeta(don.category).cls + '">' + icon(catMeta(don.category).icon) + "</span>" +
          '<div class="row-body"><div class="row-title">' + esc(don.title) + "</div>" +
            '<div class="row-meta"><span>' + esc(donorName(don)) + "</span><span>" + don.servings + " meals</span><span>" + don.weightKg + " kg</span></div>" +
          "</div>" +
          statusPill(don.status) +
        "</div>" +
        '<div class="fact-list">' +
          '<div class="fact"><dt>Match score</dt><dd><span class="pill pill-green">' + match.score + "% match</span></dd></div>" +
          '<div class="fact"><dt>Distance & route</dt><dd>' + match.km + " km · about " + match.etaMin + " min</dd></div>" +
          '<div class="fact"><dt>Volunteer</dt><dd>' + esc(vol.name) + " · " + esc(vol.vehicle) + "</dd></div>" +
          '<div class="fact"><dt>Safe window</dt><dd>' + (S.freshness(don).expired ? "Closed" : S.duration(S.freshness(don).left) + " left") + "</dd></div>" +
          (don.notes ? '<div class="fact"><dt>Donor notes</dt><dd>' + esc(don.notes) + "</dd></div>" : "") +
        "</div>" +
        '<div class="detail-block"><h4>Before you accept</h4>' +
          '<div class="safety-line">' + icon("shield") + "<span>Confirm your kitchen can collect and serve within the safe window.</span></div>" +
        "</div>" +
      "</div>" +
      '<div class="modal-foot">' +
        '<button class="btn btn-ghost" data-action="close-modal">Cancel</button>' +
        '<button class="btn btn-primary" data-action="accept-confirm" data-id="' + don.id + '">' + icon("check") + "Accept & assign " + esc(vol.name.split(" ")[0]) + "</button>" +
      "</div>",
      true
    );
  }

  var SAFETY_ITEMS = [
    "Food was prepared inside its safe window",
    "Held at a safe temperature during storage",
    "Covered and hygienically packed for transport",
    "No signs of spoilage — smell, colour and texture checked",
    "Allergen information confirmed with the donor"
  ];

  function openSafety(id) {
    var don = S.getDonation(id);
    if (!don) return;
    var donor = S.donorById(don.donorId);
    var ngo = don.matchedNgoId ? S.ngoById(don.matchedNgoId) : null;

    openModal(
      modalHead("Safety check", "Before you set off", "") +
      '<form id="safetyForm" novalidate>' +
        '<div class="modal-body">' +
          '<p class="modal-intro">Tick all five checks with the donor present. This record is attached to the pickup confirmation.</p>' +
          '<div class="modal-summary">' +
            '<span class="row-media">' + icon("pin") + "</span>" +
            '<div class="row-body"><div class="row-title">' + esc(don.title) + "</div>" +
              '<div class="row-meta"><span>' + esc(donor ? donor.name : "") + "</span><span>" + don.servings + " meals</span><span>→ " + esc(ngo ? ngo.name : "") + "</span></div>" +
            "</div>" +
          "</div>" +
          SAFETY_ITEMS.map(function (text, i) {
            return '<label class="check"><input type="checkbox" data-check="' + i + '"><span>' + text + "</span></label>";
          }).join("") +
          '<p class="hint" style="margin-top:10px">' + icon("info") + " All checks are required before the route starts.</p>" +
        "</div>" +
        '<div class="modal-foot">' +
          '<button type="button" class="btn btn-ghost" data-action="close-modal">Cancel</button>' +
          '<button type="submit" class="btn btn-primary" id="safetyStart" disabled>' + icon("route") + "Start route</button>" +
        "</div>" +
      "</form>",
      true
    );

    var form = document.getElementById("safetyForm");
    var checks = $$('input[type="checkbox"]', form);
    var startBtn = document.getElementById("safetyStart");
    form.addEventListener("change", function () {
      var all = checks.every(function (c) { return c.checked; });
      startBtn.disabled = !all;
      checks.forEach(function (c) {
        c.closest(".check").classList.toggle("checked", c.checked);
      });
    });
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var selected = checks.filter(function (c) { return c.checked; }).map(function (c) {
        return c.closest(".check").querySelector("span").textContent;
      });
      if (selected.length !== SAFETY_ITEMS.length) return;
      var res = S.startPickup(don.id, selected);
      if (!res.ok) { toast(res.message, "error"); return; }
      closeModal();
      render();
      toast("Route started. " + res.etaMin + " min to " + (donor ? donor.name : "the donor") + ".");
    });
  }

  function openProof(id) {
    var don = S.getDonation(id);
    if (!don) return;
    var donor = S.donorById(don.donorId);
    state.modalPhoto = null;

    openModal(
      modalHead("Proof of pickup", "Confirm the handover", "") +
      '<form id="proofForm" novalidate>' +
        '<div class="modal-body">' +
          '<p class="modal-intro">Photograph the packed food as you collect it. The photo is shared with the donor to close the safety loop.</p>' +
          '<div class="modal-summary">' +
            '<span class="row-media">' + icon("camera") + "</span>" +
            '<div class="row-body"><div class="row-title">' + esc(don.title) + "</div>" +
              '<div class="row-meta"><span>' + esc(donor ? donor.name : "") + "</span><span>" + don.servings + " meals</span><span>FD handover</span></div>" +
            "</div>" +
          "</div>" +
          '<label class="upload" id="proofUpload">' + icon("camera") +
            "<strong>Add a pickup photo</strong><span>JPG or PNG · required for confirmation</span>" +
            '<input type="file" id="proofInput" accept="image/*">' +
          "</label>" +
          '<div id="proofPreview"></div>' +
          '<div class="form-error-box" id="proofError">Add a photo of the packed food to confirm.</div>' +
          '<div class="detail-block"><h4>Safety checklist completed</h4><div class="safety-summary">' +
            (don.safetyChecks && don.safetyChecks.length ? don.safetyChecks : SAFETY_ITEMS).map(function (c) {
              return '<div class="safety-line">' + icon("check") + "<span>" + esc(c) + "</span></div>";
            }).join("") +
          "</div></div>" +
        "</div>" +
        '<div class="modal-foot">' +
          '<button type="button" class="btn btn-ghost" data-action="close-modal">Cancel</button>' +
          '<button type="submit" class="btn btn-primary" id="proofSubmit" disabled>' + icon("check") + "Confirm pickup</button>" +
        "</div>" +
      "</form>",
      true
    );

    var input = document.getElementById("proofInput");
    var preview = document.getElementById("proofPreview");
    var submit = document.getElementById("proofSubmit");
    var error = document.getElementById("proofError");

    input.addEventListener("change", function () {
      if (!input.files || !input.files[0]) return;
      readImage(input.files[0]).then(function (dataUrl) {
        state.modalPhoto = dataUrl;
        preview.innerHTML = '<div class="upload-preview"><img src="' + dataUrl + '" alt="Pickup proof preview"></div>';
        submit.disabled = false;
        error.classList.remove("show");
      }).catch(function (err) { toast(err.message, "error"); });
    });

    document.getElementById("proofForm").addEventListener("submit", function (e) {
      e.preventDefault();
      if (!state.modalPhoto) {
        error.classList.add("show");
        return;
      }
      var res = S.confirmPickup(don.id, don.safetyChecks, state.modalPhoto);
      if (!res.ok) { toast(res.message, "error"); return; }
      closeModal();
      render();
      toast("Pickup confirmed. Proof shared with " + (donor ? donor.name : "the donor") + ".");
    });
  }

  function openDelivery(id) {
    var don = S.getDonation(id);
    if (!don) return;
    var ngo = S.ngoById(don.matchedNgoId);
    openModal(
      modalHead("Handover verification", "Complete this delivery", "") +
      '<form id="deliveryForm" novalidate>' +
        '<div class="modal-body">' +
          '<p class="modal-intro">Ask ' + esc(ngo ? ngo.name : "the receiver") + " for the 4-digit handover code shown on their donation. The code verifies that the food reached the right people.</p>" +
          '<div class="modal-summary">' +
            '<span class="avatar avatar-amber avatar-lg">' + (ngo ? ngo.short : "N") + "</span>" +
            '<div class="row-body"><div class="row-title">' + esc(ngo ? ngo.name : "Receiver") + "</div>" +
              '<div class="row-meta"><span>' + esc(don.title) + "</span><span>" + don.servings + " meals</span><span>" + don.weightKg + " kg</span></div>" +
            "</div>" +
          "</div>" +
          '<div class="field"><label class="lbl" for="handoverCode">Handover code</label>' +
            '<input class="code-input" id="handoverCode" inputmode="numeric" maxlength="4" placeholder="••••" autocomplete="one-time-code">' +
            '<div class="hint">Ask the receiver to read the code from their donation card.</div>' +
          "</div>" +
          '<div class="form-error-box" id="codeError"></div>' +
          '<p class="hint" style="margin-top:12px">Prototype aid — the demo code for ' + don.id + " is <strong>" + don.handoverCode + "</strong>.</p>" +
        "</div>" +
        '<div class="modal-foot">' +
          '<button type="button" class="btn btn-ghost" data-action="close-modal">Cancel</button>' +
          '<button type="submit" class="btn btn-primary">' + icon("shield") + "Verify & complete</button>" +
        "</div>" +
      "</form>",
      true
    );

    var form = document.getElementById("deliveryForm");
    var input = document.getElementById("handoverCode");
    var error = document.getElementById("codeError");
    input.focus();
    input.addEventListener("input", function () {
      input.value = input.value.replace(/\D/g, "").slice(0, 4);
      error.classList.remove("show");
    });
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (!/^\d{4}$/.test(input.value)) {
        error.textContent = "Enter the 4-digit handover code.";
        error.classList.add("show");
        return;
      }
      var res = S.completeDelivery(don.id, input.value);
      if (!res.ok) {
        error.textContent = res.message;
        error.classList.add("show");
        return;
      }
      closeModal();
      render();
      toast("Delivery complete. " + don.servings + " meals rescued at " + (ngo ? ngo.name : "the receiver") + ".");
      setTimeout(function () { openDeliverySuccess(don, ngo); }, 220);
    });
  }

  function openDeliverySuccess(don, ngo) {
    var co2 = Math.round(don.weightKg * S.CO2_PER_KG);
    openModal(
      modalHead("Loop closed", "Delivery complete", "") +
      '<div class="modal-body"><div class="success-hero">' +
        '<div class="big-check">' + icon("check") + "</div>" +
        "<h3>Meals delivered. Proof on record.</h3>" +
        "<p>" + don.servings + " servings of " + esc(don.title) + " reached " + esc(ngo ? ngo.name : "the receiver") + ". The donor has been notified and the impact dashboard is updated.</p>" +
      "</div>" +
      '<div class="impact-uplift">' +
        '<div class="uplift"><strong>+' + don.servings + "</strong><span>meals rescued</span></div>" +
        '<div class="uplift"><strong>+' + don.weightKg + "</strong><span>kg food saved</span></div>" +
        '<div class="uplift"><strong>+' + co2 + "</strong><span>kg CO₂e avoided</span></div>" +
      "</div></div>" +
      '<div class="modal-foot">' +
        '<button class="btn btn-ghost" data-action="close-modal">Done</button>' +
        '<button class="btn btn-primary" data-action="go-page" data-page="impact">View impact ' + icon("arrow") + "</button>" +
      "</div>",
      true
    );
  }

  /* ------------------------------------------------------------
     Donation detail
     ------------------------------------------------------------ */
  function timelineMarkup(don) {
    var steps = [
      { label: "Posted", at: don.createdAt },
      { label: "Accepted", at: don.acceptedAt },
      { label: "Picked up", at: don.pickedAt },
      { label: "Delivered", at: don.deliveredAt }
    ];
    var currentIndex = 0;
    if (don.deliveredAt) currentIndex = 4;
    else if (don.pickedAt) currentIndex = 3;
    else if (don.status === "pickup") currentIndex = 2;
    else if (don.acceptedAt) currentIndex = 2;
    return '<div class="timeline">' + steps.map(function (s, i) {
      var done = !!s.at;
      var current = !done && i === currentIndex;
      return '<div class="tl-step ' + (done ? "done" : current ? "current" : "") + '">' +
        '<span class="tl-dot">' + icon("check") + "</span>" +
        '<div class="tl-body"><div class="tl-label">' + s.label + "</div>" +
          '<div class="tl-time">' + (s.at ? S.fmtDate(s.at) + " · " + S.fmtTime(s.at) : "Pending") + "</div>" +
        "</div>" +
      "</div>";
    }).join("") + "</div>";
  }

  function openDetails(id) {
    var don = S.getDonation(id);
    if (!don) return;
    var donor = S.donorById(don.donorId);
    var ngo = don.matchedNgoId ? S.ngoById(don.matchedNgoId) : null;
    var suggestion = !ngo ? S.bestMatch(don) : null;
    var vol = don.volunteerId ? S.volunteerById(don.volunteerId) : null;
    var f = S.freshness(don);
    var me = S.persona();

    var facts =
      '<div class="fact"><dt>Donor</dt><dd>' + esc(donor ? donor.name : "") + "</dd></div>" +
      '<div class="fact"><dt>Receiver</dt><dd>' + (ngo ? esc(ngo.name) : suggestion ? esc(suggestion.ngo.name) + ' <span class="pill pill-amber">suggested</span>' : "Not matched yet") + "</dd></div>" +
      (vol ? '<div class="fact"><dt>Volunteer</dt><dd>' + esc(vol.name) + " · " + esc(vol.vehicle) + "</dd></div>" : "") +
      '<div class="fact"><dt>Servings</dt><dd>' + don.servings + " meals</dd></div>" +
      '<div class="fact"><dt>Weight</dt><dd>' + don.weightKg + " kg (est.)</dd></div>" +
      '<div class="fact"><dt>Diet</dt><dd>' + dietLabel(don.diet) + "</dd></div>" +
      '<div class="fact"><dt>Prepared</dt><dd>' + S.fmtTime(don.preparedAt) + " · " + S.fmtDate(don.preparedAt) + "</dd></div>" +
      '<div class="fact"><dt>Safe window</dt><dd>' + (["available", "matched", "pickup"].indexOf(don.status) >= 0 ? (f.expired ? "Closed" : S.duration(f.left) + " left") : don.safeHours + " hours") + "</dd></div>" +
      '<div class="fact"><dt>Pickup address</dt><dd>' + esc(don.address) + "</dd></div>" +
      '<div class="fact"><dt>Donation ID</dt><dd>' + don.id + "</dd></div>";

    var foodPhoto = don.photo
      ? '<div class="detail-block"><h4>Food photo</h4><div class="proof-photo"><img src="' + don.photo + '" alt="Food photo for ' + esc(don.title) + '"></div></div>'
      : "";

    var proof = don.proofPhoto
      ? '<div class="detail-block"><h4>Proof of pickup</h4><div class="proof-photo"><img src="' + don.proofPhoto + '" alt="Proof of pickup for ' + esc(don.title) + '"></div></div>'
      : "";

    var safety = don.safetyChecks && don.safetyChecks.length
      ? '<div class="detail-block"><h4>Safety checklist</h4><div class="safety-summary">' +
        don.safetyChecks.map(function (c) { return '<div class="safety-line">' + icon("check") + "<span>" + esc(c) + "</span></div>"; }).join("") +
      "</div></div>"
      : "";

    var code = (me.role === "ngo" && don.matchedNgoId === me.id && don.status !== "delivered")
      ? '<div class="detail-block"><h4>Handover code</h4><div class="code-chip">' + icon("shield") + "<strong>" + don.handoverCode + "</strong><span>share with the volunteer</span></div></div>"
      : "";

    var notes = don.notes
      ? '<div class="detail-block"><h4>Donor notes</h4><div class="detail-note">' + esc(don.notes) + "</div></div>"
      : "";

    openModal(
      modalHead(don.id + " · " + esc(don.category), esc(don.title), '<div style="margin-top:7px">' + statusPill(don.status) +
        (don.matchScore ? ' <span class="pill pill-green">' + don.matchScore + "% match</span>" : "") + "</div>") +
      '<div class="modal-body"><div class="detail-grid">' +
        "<div>" + mapOuter(don) +
          '<div class="detail-block"><h4>Journey</h4>' + timelineMarkup(don) + "</div>" +
          foodPhoto +
          proof +
        "</div>" +
        "<div><dl class=\"fact-list\">" + facts + "</dl>" + code + safety + notes + "</div>" +
      "</div></div>" +
      '<div class="modal-foot">' +
        cardActionMarkup(don) +
        '<button class="btn btn-ghost" data-action="close-modal">Close</button>' +
      "</div>",
      true
    );
  }

  /* ------------------------------------------------------------
     Photo reading
     ------------------------------------------------------------ */
  function readImage(file) {
    return new Promise(function (resolve, reject) {
      if (!file || !/^image\//.test(file.type)) {
        reject(new Error("Please choose an image file."));
        return;
      }
      if (file.size > 12 * 1024 * 1024) {
        reject(new Error("That image is too large — choose one under 12 MB."));
        return;
      }
      var reader = new FileReader();
      reader.onerror = function () { reject(new Error("Could not read that image.")); };
      reader.onload = function () {
        var img = new Image();
        img.onerror = function () { reject(new Error("Could not load that image.")); };
        img.onload = function () {
          var max = 900;
          var scale = Math.min(1, max / Math.max(img.width, img.height));
          var canvas = document.createElement("canvas");
          canvas.width = Math.max(1, Math.round(img.width * scale));
          canvas.height = Math.max(1, Math.round(img.height * scale));
          var ctx = canvas.getContext("2d");
          ctx.fillStyle = "#ffffff";
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          try {
            resolve(canvas.toDataURL("image/jpeg", 0.7));
          } catch (err) {
            reject(new Error("Could not process that image."));
          }
        };
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
  }

  /* ------------------------------------------------------------
     Actions
     ------------------------------------------------------------ */
  function acceptConfirm(id) {
    var role = S.persona().role;
    if (role !== "ngo") {
      toast("Switch to the receiver role to accept donations.", "error");
      return;
    }
    var res = S.acceptDonation(id, S.persona().id);
    if (!res.ok) { toast(res.message, "error"); return; }
    closeModal();
    render();
    toast("Accepted. " + res.volunteer.name + " will collect from " + esc(res.donation.title) + ".");
  }

  function switchRole(role, goPage) {
    closeDropdowns();
    var changed = S.persona().role !== role;
    S.setPersona(role);
    var me = S.persona();
    if (changed) toast("Now viewing as " + me.name + " · " + me.label + ".");
    if (goPage) {
      if (pageFromHash() === goPage) render();
      else location.hash = "#/" + goPage;
    } else {
      render();
    }
  }

  function continueAsNgo(id) {
    S.setPersona("ngo");
    closeModal();
    if (pageFromHash() === "donations") render();
    else location.hash = "#/donations";
    toast("Now viewing as Asha Community Kitchen · Receiver.");
    setTimeout(function () {
      if (S.getDonation(id)) openAccept(id);
    }, 260);
  }

  function resetDemo() {
    openModal(
      modalHead("Prototype settings", "Reset demo data?", "") +
      '<div class="modal-body"><p class="modal-intro">This clears every donation, photo and activity record created in this session and restores the seeded demo data. It cannot be undone.</p>' +
        '<div class="detail-note">' + icon("info") + " Use this before a fresh walkthrough or demo.</div>" +
      "</div>" +
      '<div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">Cancel</button>' +
        '<button class="btn btn-danger" data-action="reset-confirm">' + icon("refresh") + "Reset demo</button></div>"
    );
  }

  function handleSwitchRoleButton(btn) {
    var role = btn.getAttribute("data-role");
    var go = btn.getAttribute("data-go");
    switchRole(role, go);
  }

  /* ------------------------------------------------------------
     Global events
     ------------------------------------------------------------ */
  document.addEventListener("click", function (e) {
    var actionEl = e.target.closest("[data-action]");
    var action = actionEl ? actionEl.getAttribute("data-action") : null;

    if (!e.target.closest(".dropdown") && !e.target.closest('[data-action="bell"]') && !e.target.closest('[data-action="persona-menu"]')) {
      closeDropdowns();
    }

    if (actionEl && actionEl.closest("a[data-nav]")) {
      document.getElementById("sidebar").classList.remove("open");
      document.body.classList.remove("sidebar-open");
    }

    if (!action) return;

    if (action === "menu") {
      document.getElementById("sidebar").classList.add("open");
      document.body.classList.add("sidebar-open");
    } else if (action === "menu-close") {
      document.getElementById("sidebar").classList.remove("open");
      document.body.classList.remove("sidebar-open");
    } else if (action === "bell") {
      var bell = document.getElementById("bellDropdown");
      var isOpen = bell.classList.contains("open");
      closeDropdowns();
      if (!isOpen) {
        S.markSeen();
        bell.innerHTML = notificationsMarkup();
        bell.classList.add("open");
        updateBellBadge();
      }
    } else if (action === "persona-menu") {
      var pd = document.getElementById("personaDropdown");
      var open = pd.classList.contains("open");
      closeDropdowns();
      if (!open) pd.classList.add("open");
    } else if (action === "persona") {
      handleSwitchRoleButton(actionEl);
    } else if (action === "switch-role") {
      handleSwitchRoleButton(actionEl);
    } else if (action === "go-page") {
      closeModal();
      closeDropdowns();
      navigate(actionEl.getAttribute("data-page"));
    } else if (action === "reset-demo") {
      resetDemo();
    } else if (action === "reset-confirm") {
      S.reset();
      closeModal();
      S.setPersona("donor");
      render();
      toast("Demo data restored.");
    } else if (action === "accept") {
      openAccept(actionEl.getAttribute("data-id"));
    } else if (action === "accept-confirm") {
      acceptConfirm(actionEl.getAttribute("data-id"));
    } else if (action === "start-pickup") {
      openSafety(actionEl.getAttribute("data-id"));
    } else if (action === "pickup-confirm-open") {
      openProof(actionEl.getAttribute("data-id"));
    } else if (action === "delivery-open") {
      openDelivery(actionEl.getAttribute("data-id"));
    } else if (action === "details") {
      openDetails(actionEl.getAttribute("data-id"));
    } else if (action === "continue-ngo") {
      continueAsNgo(actionEl.getAttribute("data-id"));
    } else if (action === "close-modal") {
      closeModal();
    } else if (action === "open-notification") {
      var donId = actionEl.getAttribute("data-donation");
      closeDropdowns();
      if (!donId || !S.getDonation(donId)) return;
      if (pageFromHash() !== "donations") {
        navigate("donations");
        setTimeout(function () { openDetails(donId); }, 240);
      } else {
        openDetails(donId);
      }
    } else if (action === "filter") {
      state.filter = actionEl.getAttribute("data-filter");
      $$(".chip", document.querySelector(".filters")).forEach(function (c) {
        c.classList.toggle("active", c.getAttribute("data-filter") === state.filter);
      });
      renderBoardGrid();
    } else if (action === "clear-filters") {
      state.filter = "all";
      state.search = "";
      render();
    }
  });

  document.addEventListener("input", function (e) {
    if (e.target.id === "boardSearch") {
      state.search = e.target.value;
      renderBoardGrid();
    }
  });

  window.addEventListener("hashchange", function () {
    render();
  });

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
      closeDropdowns();
      document.getElementById("sidebar").classList.remove("open");
      document.body.classList.remove("sidebar-open");
    }
  });

  window.addEventListener("beforeunload", stopMaps);

  setInterval(function () {
    $$("[data-eta-donation]").forEach(function (el) {
      var don = S.getDonation(el.getAttribute("data-eta-donation"));
      if (!don) return;
      if (don.status !== "pickup" && don.status !== "picked_up") return;
      var mins = S.remainingMinutes(don);
      var text;
      if (don.status === "pickup") text = mins > 0 ? mins + " min to the donor" : "At the donor — confirm pickup";
      else text = mins > 0 ? mins + " min to the receiver" : "At the receiver — complete handover";
      if (el.textContent !== text) el.textContent = text;
    });
  }, 1000);

  /* Kick off */
  render();
})();
