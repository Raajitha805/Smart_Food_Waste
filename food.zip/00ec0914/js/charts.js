(function (global) {
  "use strict";

  var PALETTE = ["#0F6B4F", "#E9A23B", "#7457C2", "#3B8D92", "#C0503C", "#8AA79B"];

  function niceMax(value) {
    if (!value || value <= 0) return 50;
    var steps = [50, 100, 150, 200, 250, 300, 400, 500, 750, 1000, 1500, 2000];
    for (var i = 0; i < steps.length; i++) if (value <= steps[i]) return steps[i];
    return Math.ceil(value / 1000) * 1000;
  }

  function bars(el, series) {
    if (!el) return;
    var W = 640;
    var H = 268;
    var L = 40;
    var R = 10;
    var T = 26;
    var B = 30;
    var innerW = W - L - R;
    var innerH = H - T - B;
    var maxValue = niceMax(Math.max.apply(null, series.map(function (s) { return s.value; }).concat([0])));
    var slot = innerW / series.length;
    var barW = Math.min(34, slot * 0.46);

    var out = '<svg viewBox="0 0 ' + W + " " + H + '" role="img" aria-label="Meals rescued per day over the last seven days">';

    for (var g = 0; g <= 3; g++) {
      var val = (maxValue / 3) * g;
      var y = T + innerH - (val / maxValue) * innerH;
      out += '<line class="grid-line" x1="' + L + '" y1="' + y.toFixed(1) + '" x2="' + (W - R) + '" y2="' + y.toFixed(1) + '"/>';
      out += '<text x="' + (L - 8) + '" y="' + (y + 3.5).toFixed(1) + '" text-anchor="end" font-size="9.5" fill="#97a39a" font-family="Inter, system-ui, sans-serif">' + Math.round(val) + "</text>";
    }

    series.forEach(function (s, i) {
      var cx = L + slot * i + slot / 2;
      var h = (s.value / maxValue) * innerH;
      var y = T + innerH - h;
      var isToday = !!s.today;
      var fill = isToday ? "#E9A23B" : "#0F6B4F";
      var opacity = isToday ? "1" : i === series.length - 2 ? ".72" : ".88";
      out += '<rect class="bar" x="' + (cx - barW / 2).toFixed(1) + '" y="' + y.toFixed(1) + '" width="' + barW.toFixed(1) + '" height="' + Math.max(h, 2).toFixed(1) + '" rx="6" fill="' + fill + '" opacity="' + opacity + '" style="animation-delay:' + (i * 55) + 'ms">' +
        "<title>" + s.label + ": " + s.value + " meals</title></rect>";
      if (s.value > 0) {
        out += '<text class="bar-value" x="' + cx.toFixed(1) + '" y="' + (y - 8).toFixed(1) + '" text-anchor="middle">' + s.value + "</text>";
      }
      out += '<text class="bar-label' + (isToday ? " today" : "") + '" x="' + cx.toFixed(1) + '" y="' + (H - 10) + '" text-anchor="middle">' + s.label + "</text>";
    });

    out += "</svg>";
    el.innerHTML = out;
  }

  function donut(el, series) {
    if (!el) return;
    var total = series.reduce(function (sum, s) { return sum + s.value; }, 0);
    var C = 2 * Math.PI * 62;
    var offset = 0;

    var svg = '<svg viewBox="0 0 160 160" role="img" aria-label="Meals rescued by food category">';
    svg += '<circle cx="80" cy="80" r="62" fill="none" stroke="#F1ECE2" stroke-width="22"/>';
    svg += '<g transform="rotate(-90 80 80)">';
    series.forEach(function (s, i) {
      var frac = total ? s.value / total : 0;
      var len = Math.max(0, frac * C - 2.5);
      var color = PALETTE[i % PALETTE.length];
      svg += '<circle cx="80" cy="80" r="62" fill="none" stroke="' + color + '" stroke-width="22" stroke-linecap="round" ' +
        'stroke-dasharray="' + len.toFixed(2) + " " + C.toFixed(2) + '" stroke-dashoffset="' + (-offset).toFixed(2) + '">' +
        "<title>" + s.label + ": " + s.value + " meals</title></circle>";
      offset += frac * C;
    });
    svg += "</g>";
    svg += '<text x="80" y="80" text-anchor="middle" class="donut-center-num">' + total + "</text>";
    svg += '<text x="80" y="95" text-anchor="middle" class="donut-center-label">meals</text>';
    svg += "</svg>";

    var legend = '<div class="donut-legend">';
    series.forEach(function (s, i) {
      var pct = total ? Math.round((s.value / total) * 100) : 0;
      legend += '<div class="legend-item">' +
        '<span class="legend-swatch" style="background:' + PALETTE[i % PALETTE.length] + '"></span>' +
        "<span>" + s.label + "</span>" +
        '<span class="val">' + s.value + "</span>" +
        '<span class="pct">' + pct + "%</span>" +
      "</div>";
    });
    legend += "</div>";

    el.innerHTML = '<div class="donut-layout">' + svg + legend + "</div>";
  }

  function ring(pct) {
    var r = 62;
    var C = 2 * Math.PI * r;
    var p = Math.max(0, Math.min(100, pct));
    var shown = (p / 100) * C;
    return '<svg viewBox="0 0 160 160" width="150" height="150" role="img" aria-label="Weekly goal progress">' +
      '<circle cx="80" cy="80" r="' + r + '" fill="none" stroke="#E8EFE8" stroke-width="13"/>' +
      '<circle cx="80" cy="80" r="' + r + '" fill="none" stroke="#0F6B4F" stroke-width="13" stroke-linecap="round" ' +
        'stroke-dasharray="' + shown.toFixed(1) + " " + C.toFixed(1) + '" stroke-dashoffset="0" transform="rotate(-90 80 80)"/>' +
    "</svg>";
  }

  global.Charts = { bars: bars, donut: donut, ring: ring };
})(window);
