(function (global) {
  "use strict";

  var KEY = "shareplate.v1";
  var HOUR = 3600000;
  var MIN = 60000;
  var CO2_PER_KG = 2.5;
  var KM_PER_UNIT = 0.2;
  var DEMO_MINUTE_MS = 5000;
  var VERSION = 1;

  var STATUS = {
    available: { label: "Available", tone: "amber", order: 0 },
    matched: { label: "Accepted", tone: "blue", order: 1 },
    pickup: { label: "En route", tone: "blue", order: 2 },
    picked_up: { label: "Picked up", tone: "violet", order: 3 },
    delivered: { label: "Delivered", tone: "green", order: 4 }
  };

  var donors = [
    { id: "d1", name: "Sunrise Canteen", kind: "College canteen", short: "SC", you: true, coords: { x: 28, y: 40 }, address: "Sunrise Canteen, Block C, Greenfield Campus" },
    { id: "d2", name: "Green Leaf Restaurant", kind: "Restaurant", short: "GL", coords: { x: 60, y: 22 }, address: "Green Leaf Restaurant, 14 Market Road" },
    { id: "d3", name: "TechPark Food Court", kind: "Corporate cafeteria", short: "TF", coords: { x: 78, y: 52 }, address: "TechPark Food Court, Phase 2" },
    { id: "d4", name: "Block C Hostel Mess", kind: "Hostel mess", short: "BM", coords: { x: 18, y: 66 }, address: "Block C Hostel Mess, North Gate" },
    { id: "d5", name: "Annapurna Caterers", kind: "Catering service", short: "AC", coords: { x: 46, y: 78 }, address: "Annapurna Caterers, Riverside Lane" }
  ];

  var ngos = [
    { id: "n1", name: "Asha Community Kitchen", kind: "Community kitchen", short: "AK", coords: { x: 42, y: 32 }, need: "high", capacity: "120 meals / day", pref: "Cooked meal" },
    { id: "n2", name: "Hope Foundation Shelter", kind: "Night shelter", short: "HF", coords: { x: 68, y: 40 }, need: "medium", capacity: "80 meals / day", pref: "Bakery" },
    { id: "n3", name: "Seva Trust Kitchen", kind: "Charitable trust", short: "ST", coords: { x: 34, y: 62 }, need: "medium", capacity: "60 meals / day", pref: "Cooked meal" },
    { id: "n4", name: "Little Drops Children's Home", kind: "Children's home", short: "LD", coords: { x: 84, y: 70 }, need: "low", capacity: "45 meals / day", pref: "All" }
  ];

  var volunteers = [
    { id: "v1", name: "Arjun K.", short: "AK", vehicle: "Bike", deliveries: 26, coords: { x: 31, y: 34 } },
    { id: "v2", name: "Meera S.", short: "MS", vehicle: "Scooter", deliveries: 18, coords: { x: 66, y: 58 } },
    { id: "v3", name: "Ravi P.", short: "RP", vehicle: "Bike", deliveries: 31, coords: { x: 30, y: 30 } }
  ];

  var CATEGORIES = ["Cooked meal", "Bakery", "Produce", "Dairy", "Packaged"];

  function iso(ts) { return new Date(ts).toISOString(); }
  function round1(n) { return Math.round(n * 10) / 10; }
  function clamp(n, min, max) { return Math.max(min, Math.min(max, n)); }

  function coordDistance(a, b) {
    var dx = a.x - b.x;
    var dy = (a.y - b.y) * 0.625;
    return Math.sqrt(dx * dx + dy * dy) * KM_PER_UNIT;
  }

  function etaForKm(km) {
    return Math.max(4, Math.round((km / 18) * 60) + 4);
  }

  function matchesFor(donation) {
    var donor = donorById(donation.donorId);
    var origin = donation.coords || (donor ? donor.coords : { x: 50, y: 50 });
    return ngos.map(function (ngo) {
      var km = round1(coordDistance(origin, ngo.coords));
      var needBonus = ngo.need === "high" ? 8 : ngo.need === "medium" ? 4 : 0;
      var prefBonus = ngo.pref === "All" || ngo.pref === donation.category ? 4 : 0;
      var score = clamp(Math.round(94 - km * 3.2 + needBonus + prefBonus), 58, 98);
      return { ngo: ngo, km: km, etaMin: etaForKm(km), score: score };
    }).sort(function (a, b) {
      return b.score - a.score || a.km - b.km;
    });
  }

  function bestMatch(donation) { return matchesFor(donation)[0]; }

  function nearestVolunteer(coords) {
    return volunteers.slice().sort(function (a, b) {
      return coordDistance(a.coords, coords) - coordDistance(b.coords, coords);
    })[0];
  }

  function donorById(id) {
    for (var i = 0; i < donors.length; i++) if (donors[i].id === id) return donors[i];
    return null;
  }
  function ngoById(id) {
    for (var i = 0; i < ngos.length; i++) if (ngos[i].id === id) return ngos[i];
    return null;
  }
  function volunteerById(id) {
    for (var i = 0; i < volunteers.length; i++) if (volunteers[i].id === id) return volunteers[i];
    return null;
  }

  function activityId() {
    return "a-" + Date.now() + "-" + Math.floor(Math.random() * 9999);
  }

  function seed() {
    var now = Date.now();
    var donations = [];
    var nextNum = 1029;

    function pushHistory(donorId, title, category, servings, daysAgo, deliveryHour, ngoId, volunteerId, code) {
      var donor = donorById(donorId);
      var delivered = new Date();
      delivered.setDate(delivered.getDate() - daysAgo);
      delivered.setHours(deliveryHour, 15, 0, 0);
      var t = delivered.getTime();
      var id = "FD-" + nextNum++;
      donations.push({
        id: id,
        donorId: donorId,
        title: title,
        category: category,
        servings: servings,
        weightKg: round1(servings * 0.28),
        diet: "veg",
        preparedAt: iso(t - 105 * MIN),
        safeHours: 4,
        createdAt: iso(t - 95 * MIN),
        acceptedAt: iso(t - 80 * MIN),
        pickedAt: iso(t - 45 * MIN),
        deliveredAt: iso(t),
        status: "delivered",
        coords: { x: donor.coords.x, y: donor.coords.y },
        address: donor.address,
        notes: "",
        photo: null,
        proofPhoto: null,
        matchedNgoId: ngoId,
        volunteerId: volunteerId,
        handoverCode: code,
        distanceKm: round1(coordDistance(donor.coords, ngoById(ngoId).coords)),
        etaMin: 12,
        matchScore: 90,
        safetyChecks: ["Prepared within safe window", "Held at safe temperature", "Covered and packed", "No signs of spoilage", "Allergens confirmed"]
      });
    }

    pushHistory("d2", "Veg Biryani & Raita", "Cooked meal", 120, 6, 12, "n1", "v1", "6104");
    pushHistory("d4", "Chapati, Dal & Sabzi", "Cooked meal", 60, 6, 13, "n3", "v3", "2847");
    pushHistory("d3", "Sandwich Platters", "Bakery", 75, 5, 11, "n2", "v2", "9053");
    pushHistory("d5", "Paneer Curry & Roti", "Cooked meal", 90, 5, 13, "n3", "v1", "4471");
    pushHistory("d1", "Rice, Sambar & Poriyal", "Cooked meal", 140, 4, 12, "n1", "v1", "3382");
    pushHistory("d2", "Seasonal Fruit Bowls", "Produce", 55, 4, 14, "n2", "v2", "7710");
    pushHistory("d4", "Pulao & Raita", "Cooked meal", 85, 3, 13, "n3", "v3", "1269");
    pushHistory("d3", "Bakery Assortment", "Bakery", 70, 2, 10, "n2", "v2", "8894");
    pushHistory("d1", "Veg Meals with Rasam", "Cooked meal", 110, 2, 13, "n1", "v1", "5027");
    pushHistory("d5", "Dal Khichdi", "Cooked meal", 95, 1, 13, "n3", "v1", "6438");
    pushHistory("d2", "Curd Rice & Pickle", "Cooked meal", 65, 1, 12, "n1", "v2", "2905");
    pushHistory("d4", "Idli, Vada & Chutney", "Cooked meal", 80, 0, 8, "n3", "v3", "8152");

    function openDonation(cfg) {
      var donor = donorById(cfg.donorId);
      var id = "FD-" + nextNum++;
      var don = {
        id: id,
        donorId: cfg.donorId,
        title: cfg.title,
        category: cfg.category,
        servings: cfg.servings,
        weightKg: round1(cfg.servings * 0.28),
        diet: cfg.diet || "veg",
        preparedAt: iso(now - cfg.preparedMin * MIN),
        safeHours: cfg.safeHours || 4,
        createdAt: iso(now - cfg.postedMin * MIN),
        acceptedAt: null,
        pickedAt: null,
        deliveredAt: null,
        status: "available",
        coords: { x: donor.coords.x, y: donor.coords.y },
        address: donor.address,
        notes: cfg.notes || "",
        photo: null,
        proofPhoto: null,
        matchedNgoId: null,
        volunteerId: null,
        handoverCode: cfg.code || String(1000 + Math.floor(Math.random() * 9000)),
        distanceKm: null,
        etaMin: null,
        matchScore: null,
        safetyChecks: []
      };
      if (cfg.ngoId) {
        var m = matchesFor(don).filter(function (x) { return x.ngo.id === cfg.ngoId; })[0] || bestMatch(don);
        var vol = cfg.volunteerId ? volunteerById(cfg.volunteerId) : nearestVolunteer(don.coords);
        don.matchedNgoId = m.ngo.id;
        don.distanceKm = m.km;
        don.etaMin = m.etaMin;
        don.matchScore = m.score;
        don.volunteerId = vol.id;
        don.completedAt = null;
        don.status = cfg.status || "matched";
        don.acceptedAt = iso(now - (cfg.acceptedMin || 12) * MIN);
        if (don.status === "picked_up") {
          don.pickedAt = iso(now - (cfg.pickedMin || 8) * MIN);
          don.status = "picked_up";
        }
      }
      donations.push(don);
      return don;
    }

    openDonation({
      donorId: "d5",
      title: "Veg Pulao & Raita",
      category: "Cooked meal",
      servings: 40,
      preparedMin: 55,
      postedMin: 20,
      safeHours: 4,
      notes: "Contains dairy in the raita. Packed in food-grade trays with lids.",
      status: "available"
    });

    openDonation({
      donorId: "d4",
      title: "Chapati, Dal & Sabzi",
      category: "Cooked meal",
      servings: 60,
      preparedMin: 80,
      postedMin: 35,
      safeHours: 4,
      notes: "Kept hot in insulated containers until pickup. Mild spice level.",
      status: "available"
    });

    openDonation({
      donorId: "d2",
      title: "Sandwich & Samosa Platters",
      category: "Bakery",
      servings: 35,
      preparedMin: 70,
      postedMin: 45,
      safeHours: 6,
      diet: "mixed",
      notes: "Vegetarian sandwiches and baked samosas. Individually wrapped.",
      ngoId: "n1",
      volunteerId: "v1",
      code: "4821",
      status: "matched",
      acceptedMin: 11
    });

    openDonation({
      donorId: "d3",
      title: "Fruit & Curd Bowls",
      category: "Dairy",
      servings: 25,
      preparedMin: 100,
      postedMin: 70,
      safeHours: 2,
      notes: "Chilled. Keep below 5°C during transport.",
      ngoId: "n2",
      volunteerId: "v2",
      code: "7315",
      status: "picked_up",
      acceptedMin: 38,
      pickedMin: 9
    });

    openDonation({
      donorId: "d1",
      title: "Veg Fried Rice & Dal",
      category: "Cooked meal",
      servings: 30,
      preparedMin: 38,
      postedMin: 12,
      safeHours: 4,
      notes: "Packed in sealed trays at the canteen counter. Nut-free kitchen.",
      status: "available"
    });

    donations.sort(function (a, b) { return new Date(b.createdAt) - new Date(a.createdAt); });

    var activity = [
      { id: activityId(), kind: "post", text: "Sunrise Canteen posted 30 servings of Veg Fried Rice & Dal.", at: iso(now - 12 * MIN), donationId: "FD-1045" },
      { id: activityId(), kind: "post", text: "Block C Hostel Mess posted 60 servings of Chapati, Dal & Sabzi.", at: iso(now - 35 * MIN), donationId: "FD-1042" },
      { id: activityId(), kind: "post", text: "Annapurna Caterers posted 40 servings of Veg Pulao & Raita.", at: iso(now - 20 * MIN), donationId: "FD-1041" },
      { id: activityId(), kind: "accept", text: "Asha Community Kitchen accepted the sandwich platters and assigned Arjun K. for pickup.", at: iso(now - 11 * MIN), donationId: "FD-1043" },
      { id: activityId(), kind: "proof", text: "Meera S. confirmed pickup of the fruit bowls with a photo. On the way to Hope Foundation Shelter.", at: iso(now - 9 * MIN), donationId: "FD-1044" },
      { id: activityId(), kind: "deliver", text: "80 servings of Idli, Vada & Chutney were delivered to Seva Trust Kitchen this morning.", at: iso(now - 4 * HOUR), donationId: "FD-1040" }
    ];

    return {
      version: VERSION,
      persona: "donor",
      donations: donations,
      activity: activity,
      lastSeenAt: iso(now - 6 * HOUR),
      seededAt: iso(now)
    };
  }

  function load() {
    try {
      var raw = global.localStorage.getItem(KEY);
      if (!raw) return seed();
      var parsed = JSON.parse(raw);
      if (!parsed || parsed.version !== VERSION || !Array.isArray(parsed.donations)) return seed();
      return parsed;
    } catch (err) {
      return seed();
    }
  }

  var state = load();

  function save() {
    try {
      global.localStorage.setItem(KEY, JSON.stringify(state));
      return true;
    } catch (err) {
      return false;
    }
  }

  function logActivity(kind, text, donationId) {
    state.activity.unshift({
      id: activityId(),
      kind: kind,
      text: text,
      at: new Date().toISOString(),
      donationId: donationId || null
    });
    state.activity = state.activity.slice(0, 80);
  }

  function donById(id) {
    for (var i = 0; i < state.donations.length; i++) {
      if (state.donations[i].id === id) return state.donations[i];
    }
    return null;
  }

  function nextDonationId() {
    var max = 1000;
    state.donations.forEach(function (d) {
      var n = parseInt(String(d.id).replace(/[^0-9]/g, ""), 10);
      if (n > max) max = n;
    });
    return "FD-" + (max + 1);
  }

  function createdAtToday(iso) {
    if (!iso) return false;
    var d = new Date(iso);
    var n = new Date();
    return d.getFullYear() === n.getFullYear() && d.getMonth() === n.getMonth() && d.getDate() === n.getDate();
  }

  function createDonation(input) {
    var donor = donors[0];
    var now = Date.now();
    var servings = clamp(parseInt(input.servings, 10) || 0, 1, 1000);
    var don = {
      id: nextDonationId(),
      donorId: donor.id,
      title: String(input.title || "Surplus food").trim(),
      category: CATEGORIES.indexOf(input.category) >= 0 ? input.category : "Cooked meal",
      servings: servings,
      weightKg: round1(servings * 0.28),
      diet: input.diet || "veg",
      preparedAt: input.preparedAt || iso(now - 45 * MIN),
      safeHours: Number(input.safeHours) || 4,
      createdAt: iso(now),
      acceptedAt: null,
      pickedAt: null,
      deliveredAt: null,
      status: "available",
      coords: { x: donor.coords.x, y: donor.coords.y },
      address: String(input.address || donor.address).trim(),
      notes: String(input.notes || "").trim(),
      photo: input.photo || null,
      proofPhoto: null,
      matchedNgoId: null,
      volunteerId: null,
      handoverCode: String(1000 + Math.floor(Math.random() * 9000)),
      distanceKm: null,
      etaMin: null,
      matchScore: null,
      safetyChecks: []
    };
    state.donations.unshift(don);
    var match = bestMatch(don);
    logActivity(
      "post",
      donor.name + " posted " + servings + " servings of " + don.title + ". Closest match: " + match.ngo.name + ".",
      don.id
    );
    save();
    return don;
  }

  function acceptDonation(id, ngoId) {
    var don = donById(id);
    if (!don) return { ok: false, message: "Donation not found." };
    if (don.status !== "available") return { ok: false, message: "This donation has already been accepted." };
    var match;
    if (ngoId) {
      match = matchesFor(don).filter(function (m) { return m.ngo.id === ngoId; })[0];
    }
    if (!match) match = bestMatch(don);
    var vol = nearestVolunteer(don.coords);
    don.status = "matched";
    don.matchedNgoId = match.ngo.id;
    don.volunteerId = vol.id;
    don.distanceKm = match.km;
    don.etaMin = match.etaMin;
    don.matchScore = match.score;
    don.acceptedAt = new Date().toISOString();
    logActivity(
      "accept",
      match.ngo.name + " accepted " + don.servings + " servings of " + don.title + ". " + vol.name + " assigned for pickup.",
      don.id
    );
    save();
    return { ok: true, donation: don, match: match, volunteer: vol };
  }

  function startPickup(id, checks) {
    var don = donById(id);
    if (!don || don.status !== "matched") return { ok: false, message: "This pickup is not ready to start." };
    var vol = volunteerById(don.volunteerId) || nearestVolunteer(don.coords);
    var donor = donorById(don.donorId);
    var legKm = round1(coordDistance(vol.coords, donor.coords));
    don.status = "pickup";
    don.pickupStartedAt = new Date().toISOString();
    don.pickupEtaMin = etaForKm(legKm);
    don.deliveryEtaMin = don.etaMin || etaForKm(don.distanceKm || 3);
    don.safetyChecks = checks || [];
    logActivity("pickup", vol.name + " started the pickup route to " + donor.name + ".", don.id);
    save();
    return { ok: true, donation: don, etaMin: don.pickupEtaMin };
  }

  function confirmPickup(id, checks, photo) {
    var don = donById(id);
    if (!don || (don.status !== "pickup" && don.status !== "matched")) {
      return { ok: false, message: "This pickup cannot be confirmed right now." };
    }
    don.status = "picked_up";
    don.pickedAt = new Date().toISOString();
    don.safetyChecks = checks || [];
    don.proofPhoto = photo || null;
    var vol = volunteerById(don.volunteerId);
    logActivity(
      "proof",
      (vol ? vol.name : "A volunteer") + " confirmed pickup of " + don.servings + " servings of " + don.title + " with a photo. Proof shared with the donor.",
      don.id
    );
    save();
    return { ok: true, donation: don };
  }

  function completeDelivery(id, code) {
    var don = donById(id);
    if (!don || don.status !== "picked_up") return { ok: false, message: "This delivery is not ready to complete." };
    if (String(code).trim() !== String(don.handoverCode)) {
      return { ok: false, message: "That code does not match. Ask the receiver for the 4-digit handover code." };
    }
    var ngo = ngoById(don.matchedNgoId);
    don.status = "delivered";
    don.deliveredAt = new Date().toISOString();
    logActivity(
      "deliver",
      don.servings + " servings of " + don.title + " were delivered to " + ngo.name + ". Handover verified with code.",
      don.id
    );
    save();
    return { ok: true, donation: don };
  }

  function setPersona(role) {
    if (role !== "donor" && role !== "ngo" && role !== "volunteer") return;
    state.persona = role;
    save();
  }

  function persona() {
    if (state.persona === "ngo") {
      var n = ngos[0];
      return { role: "ngo", id: n.id, name: n.name, label: "Receiver", initials: n.short, sub: "Community kitchen", person: n };
    }
    if (state.persona === "volunteer") {
      var v = volunteers[0];
      return { role: "volunteer", id: v.id, name: v.name, label: "Volunteer", initials: v.short, sub: "Pickup & delivery", person: v };
    }
    var d = donors[0];
    return { role: "donor", id: d.id, name: d.name, label: "Donor", initials: d.short, sub: "You are sharing surplus", person: d };
  }

  function metrics() {
    var delivered = state.donations.filter(function (d) { return d.status === "delivered"; });
    var meals = 0;
    var weight = 0;
    delivered.forEach(function (d) { meals += d.servings; weight += d.weightKg; });
    weight = round1(weight);
    var active = state.donations.filter(function (d) { return d.status !== "delivered"; });
    var available = active.filter(function (d) { return d.status === "available"; });
    var weekStart = new Date();
    weekStart.setHours(0, 0, 0, 0);
    weekStart.setDate(weekStart.getDate() - 6);
    var weekMeals = 0;
    delivered.forEach(function (d) {
      if (new Date(d.deliveredAt).getTime() >= weekStart.getTime()) weekMeals += d.servings;
    });
    var pendingProof = state.donations.filter(function (d) { return d.status === "picked_up"; }).length;
    return {
      meals: meals,
      weight: weight,
      co2: Math.round(weight * CO2_PER_KG),
      active: active.length,
      available: available.length,
      deliveredCount: delivered.length,
      weekMeals: weekMeals,
      co2PerKg: CO2_PER_KG,
      pendingProof: pendingProof,
      partners: ngos.length
    };
  }

  function weekSeries() {
    var days = [];
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    for (var i = 6; i >= 0; i--) {
      var d = new Date(today.getTime() - i * 24 * HOUR);
      days.push({
        key: d.getFullYear() + "-" + d.getMonth() + "-" + d.getDate(),
        label: d.toLocaleDateString("en-US", { weekday: "short" }),
        value: 0,
        today: i === 0
      });
    }
    state.donations.forEach(function (don) {
      if (don.status !== "delivered" || !don.deliveredAt) return;
      var d = new Date(don.deliveredAt);
      if (d.getTime() < today.getTime() - 6 * 24 * HOUR) return;
      var key = d.getFullYear() + "-" + d.getMonth() + "-" + d.getDate();
      for (var i = 0; i < days.length; i++) {
        if (days[i].key === key) { days[i].value += don.servings; break; }
      }
    });
    return days;
  }

  function categorySeries() {
    var map = {};
    state.donations.forEach(function (don) {
      if (don.status !== "delivered") return;
      map[don.category] = (map[don.category] || 0) + don.servings;
    });
    return Object.keys(map).map(function (k) { return { label: k, value: map[k] }; })
      .sort(function (a, b) { return b.value - a.value; });
  }

  function leaderboard() {
    var map = {};
    state.donations.forEach(function (don) {
      if (don.status !== "delivered") return;
      if (!map[don.donorId]) map[don.donorId] = { id: don.donorId, meals: 0, donations: 0 };
      map[don.donorId].meals += don.servings;
      map[don.donorId].donations += 1;
    });
    return Object.keys(map).map(function (k) {
      var d = donorById(k);
      return {
        id: k,
        name: d ? d.name : k,
        short: d ? d.short : "?",
        you: d ? !!d.you : false,
        meals: map[k].meals,
        donations: map[k].donations
      };
    }).sort(function (a, b) { return b.meals - a.meals; });
  }

  function freshness(don) {
    var expiry = new Date(don.preparedAt).getTime() + don.safeHours * HOUR;
    var total = don.safeHours * HOUR;
    var left = expiry - Date.now();
    return {
      left: left,
      pct: clamp((left / total) * 100, 0, 100),
      expired: left <= 0,
      expiry: expiry
    };
  }

  function legProgress(don) {
    var now = Date.now();
    if (don.status === "pickup" && don.pickupStartedAt) {
      var dur = (don.pickupEtaMin || 8) * DEMO_MINUTE_MS;
      return clamp((now - new Date(don.pickupStartedAt).getTime()) / dur, 0, 1);
    }
    if (don.status === "picked_up" && don.pickedAt) {
      var dur2 = (don.deliveryEtaMin || 10) * DEMO_MINUTE_MS;
      return clamp((now - new Date(don.pickedAt).getTime()) / dur2, 0, 1);
    }
    if (don.status === "delivered") return 1;
    return 0;
  }

  function remainingMinutes(don) {
    var p = legProgress(don);
    if (don.status === "pickup") return Math.max(0, Math.ceil((1 - p) * (don.pickupEtaMin || 8)));
    if (don.status === "picked_up") return Math.max(0, Math.ceil((1 - p) * (don.deliveryEtaMin || 10)));
    return 0;
  }

  function markSeen() {
    state.lastSeenAt = new Date().toISOString();
    save();
  }

  function unreadCount() {
    var seen = new Date(state.lastSeenAt).getTime();
    return state.activity.filter(function (a) { return new Date(a.at).getTime() > seen; }).length;
  }

  function reset() {
    state = seed();
    save();
  }

  function fmtNum(n) {
    return Number(n || 0).toLocaleString("en-IN");
  }
  function fmtTime(value) {
    return new Date(value).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
  }
  function fmtDate(value) {
    return new Date(value).toLocaleDateString("en-US", { weekday: "short", day: "numeric", month: "short" });
  }
  function timeAgo(value) {
    var diff = Date.now() - new Date(value).getTime();
    if (diff < 0) diff = 0;
    var mins = Math.round(diff / MIN);
    if (mins < 1) return "just now";
    if (mins < 60) return mins + " min ago";
    var hrs = Math.round(mins / 60);
    if (hrs < 24) return hrs + " h ago";
    if (hrs < 48) return "yesterday";
    return fmtDate(value);
  }
  function duration(ms) {
    if (ms <= 0) return "0m";
    var mins = Math.ceil(ms / MIN);
    if (mins < 60) return mins + "m";
    var h = Math.floor(mins / 60);
    var m = mins % 60;
    return m ? h + "h " + m + "m" : h + "h";
  }

  global.Store = {
    KEY: KEY,
    HOUR: HOUR,
    MIN: MIN,
    DEMO_MINUTE_MS: DEMO_MINUTE_MS,
    CO2_PER_KG: CO2_PER_KG,
    STATUS: STATUS,
    CATEGORIES: CATEGORIES,
    donors: donors,
    ngos: ngos,
    volunteers: volunteers,
    get state() { return state; },
    donorById: donorById,
    ngoById: ngoById,
    volunteerById: volunteerById,
    getDonation: donById,
    matchesFor: matchesFor,
    bestMatch: bestMatch,
    nearestVolunteer: nearestVolunteer,
    coordDistance: coordDistance,
    etaForKm: etaForKm,
    createDonation: createDonation,
    acceptDonation: acceptDonation,
    startPickup: startPickup,
    confirmPickup: confirmPickup,
    completeDelivery: completeDelivery,
    setPersona: setPersona,
    persona: persona,
    metrics: metrics,
    weekSeries: weekSeries,
    categorySeries: categorySeries,
    leaderboard: leaderboard,
    freshness: freshness,
    legProgress: legProgress,
    remainingMinutes: remainingMinutes,
    createdAtToday: createdAtToday,
    markSeen: markSeen,
    unreadCount: unreadCount,
    activity: function () { return state.activity; },
    reset: reset,
    save: save,
    fmtNum: fmtNum,
    fmtTime: fmtTime,
    fmtDate: fmtDate,
    timeAgo: timeAgo,
    duration: duration,
    round1: round1
  };
})(window);
