(function (global) {
  "use strict";

  var W = 1000;
  var H = 625;

  function px(x) { return (x / 100) * W; }
  function py(y) { return (y / 100) * H; }

  function curve(a, b, bend) {
    var x1 = px(a.x), y1 = py(a.y), x2 = px(b.x), y2 = py(b.y);
    var mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
    var dx = x2 - x1, dy = y2 - y1;
    var len = Math.sqrt(dx * dx + dy * dy) || 1;
    var nx = -dy / len, ny = dx / len;
    var cx = mx + nx * len * (bend || 0);
    var cy = my + ny * len * (bend || 0);
    return "M " + x1.toFixed(1) + " " + y1.toFixed(1) + " Q " + cx.toFixed(1) + " " + cy.toFixed(1) + " " + x2.toFixed(1) + " " + y2.toFixed(1);
  }

  function label(name, x, y, offset, tone) {
    var width = Math.min(196, Math.max(58, name.length * 6.3 + 20));
    var bx = Math.min(W - width / 2 - 8, Math.max(width / 2 + 8, x));
    var by = y + offset;
    var fill = tone === "amber" ? "#8a5a12" : tone === "blue" ? "#1f4f9c" : "#24503c";
    return (
      '<g class="map-pin-label" transform="translate(' + bx.toFixed(1) + "," + by.toFixed(1) + ')">' +
        '<rect x="' + (-width / 2).toFixed(1) + '" y="-18" width="' + width.toFixed(1) + '" height="23" rx="7" fill="rgba(255,255,255,.96)" stroke="#E2DDD1" stroke-width="1"/>' +
        '<text x="0" y="-2" text-anchor="middle" font-size="11.5" font-weight="600" fill="' + fill + '">' + escapeXml(name) + "</text>" +
      "</g>"
    );
  }

  function escapeXml(str) {
    return String(str).replace(/[<>&"]/g, function (c) {
      return { "<": "&lt;", ">": "&gt;", "&": "&amp;", '"': "&quot;" }[c];
    });
  }

  function baseMap() {
    return (
      '<defs>' +
        '<pattern id="mgrid" width="46" height="46" patternUnits="userSpaceOnUse">' +
          '<path d="M46 0H0V46" fill="none" stroke="#DFE7DB" stroke-width="1"/>' +
        "</pattern>" +
        '<linearGradient id="riverGrad" x1="0" y1="0" x2="1" y2="1">' +
          '<stop offset="0" stop-color="#D3E8E6"/><stop offset="1" stop-color="#C3DEDD"/>' +
        "</linearGradient>" +
      "</defs>" +
      '<rect width="' + W + '" height="' + H + '" fill="#EDF2E9"/>' +
      '<rect width="' + W + '" height="' + H + '" fill="url(#mgrid)" opacity=".85"/>' +

      '<path d="M -30 500 C 120 468, 232 572, 382 546 C 542 518, 622 452, 762 500 C 872 534, 952 562, 1032 520 L 1032 700 L -30 700 Z" fill="url(#riverGrad)"/>' +
      '<path d="M -20 512 C 130 482, 240 584, 390 558 C 545 530, 626 466, 764 512 C 872 546, 954 572, 1030 534" fill="none" stroke="#BCDBDA" stroke-width="2"/>' +
      '<text x="792" y="592" font-size="9" letter-spacing="2.4" fill="#83A9A6" transform="rotate(-4 792 592)">RIVERSIDE</text>' +

      '<ellipse cx="764" cy="138" rx="132" ry="76" fill="#DFECD8"/>' +
      '<ellipse cx="176" cy="238" rx="96" ry="58" fill="#E2EED9"/>' +
      '<ellipse cx="544" cy="352" rx="58" ry="34" fill="#E4F0DC" opacity=".8"/>' +
      '<g fill="#CFE3C6">' +
        '<circle cx="710" cy="118" r="9"/><circle cx="760" cy="96" r="6"/><circle cx="812" cy="132" r="8"/>' +
        '<circle cx="740" cy="166" r="5"/><circle cx="826" cy="172" r="6"/><circle cx="146" cy="226" r="6"/>' +
        '<circle cx="188" cy="248" r="8"/><circle cx="214" cy="222" r="5"/>' +
      "</g>" +
      '<text x="722" y="74" font-size="9" letter-spacing="2.4" fill="#8DAA86">CENTRAL PARK</text>' +

      '<g fill="#E8EEE3" stroke="#E0E7DA" stroke-width="1">' +
        '<rect x="448" y="104" width="64" height="42" rx="6"/>' +
        '<rect x="314" y="330" width="72" height="46" rx="6"/>' +
        '<rect x="610" y="250" width="56" height="38" rx="6"/>' +
        '<rect x="864" y="256" width="68" height="48" rx="6"/>' +
        '<rect x="96" y="350" width="74" height="42" rx="6"/>' +
        '<rect x="628" y="108" width="46" height="34" rx="6"/>' +
      "</g>" +

      '<g fill="none" stroke-linecap="round">' +
        '<path d="M -20 180 H 1020" stroke="#DED9CC" stroke-width="30"/>' +
        '<path d="M -20 180 H 1020" stroke="#FBFCF8" stroke-width="23"/>' +
        '<path d="M -20 420 H 1020" stroke="#DED9CC" stroke-width="24"/>' +
        '<path d="M -20 420 H 1020" stroke="#FBFCF8" stroke-width="18"/>' +
        '<path d="M 250 -20 V 645" stroke="#DED9CC" stroke-width="28"/>' +
        '<path d="M 250 -20 V 645" stroke="#FBFCF8" stroke-width="21"/>' +
        '<path d="M 560 -20 V 645" stroke="#DED9CC" stroke-width="24"/>' +
        '<path d="M 560 -20 V 645" stroke="#FBFCF8" stroke-width="18"/>' +
        '<path d="M 806 -20 V 645" stroke="#DED9CC" stroke-width="22"/>' +
        '<path d="M 806 -20 V 645" stroke="#FBFCF8" stroke-width="16"/>' +
        '<path d="M -40 640 L 880 40" stroke="#DED9CC" stroke-width="20"/>' +
        '<path d="M -40 640 L 880 40" stroke="#FBFCF8" stroke-width="14"/>' +
        '<path d="M 386 210 H 590" stroke="#F6F8F2" stroke-width="10"/>' +
        '<path d="M 660 330 V 470" stroke="#F6F8F2" stroke-width="10"/>' +
      "</g>" +

      '<g fill="none" stroke="#D7DED3" stroke-width="1.5">' +
        '<path d="M 250 180 L 560 420" stroke-dasharray="1 12" stroke-linecap="round" opacity=".7"/>' +
        '<path d="M 560 180 L 806 420" stroke-dasharray="1 12" stroke-linecap="round" opacity=".7"/>' +
      "</g>" +

      '<text x="630" y="172" font-size="9" letter-spacing="2.2" fill="#A6B1A4">MARKET ROAD</text>' +
      '<text x="72" y="412" font-size="9" letter-spacing="2.2" fill="#A6B1A4">CAMPUS LOOP</text>' +
      '<text x="812" y="300" font-size="9" letter-spacing="2.2" fill="#A6B1A4" transform="rotate(90 812 300)">RING ROAD</text>'
    );
  }

  function pin(point, name, tone, opts) {
    var x = px(point.x), y = py(point.y);
    var color = tone === "amber" ? "#D3922C" : tone === "blue" ? "#2E6BD6" : "#0F6B4F";
    var ring = tone === "amber" ? "#FBEFD9" : tone === "blue" ? "#E8EFFC" : "#E7F3EC";
    var offset = opts && opts.labelBelow ? 40 : -34;
    var out = '<g transform="translate(' + x.toFixed(1) + "," + y.toFixed(1) + ')">' +
      '<circle r="25" fill="' + color + '" opacity=".1"/>' +
      '<circle r="16" fill="#fff" stroke="' + color + '" stroke-width="3.2"/>' +
      '<circle r="6.5" fill="' + color + '"/>';
    if (tone === "blue") {
      out += '<circle r="16" fill="#0B3A2B" stroke="#fff" stroke-width="2.4"/>' +
        '<text y="3.6" text-anchor="middle" font-size="9" font-weight="700" fill="#fff" font-family="Inter, system-ui, sans-serif">' + escapeXml(opts && opts.initials ? opts.initials : "GO") + "</text>";
    } else {
      out += '<circle r="3" fill="' + ring + '"/>';
    }
    out += "</g>";
    if (name) out += label(name, x, y, offset, tone);
    return out;
  }

  function checkBadge(point) {
    var x = px(point.x), y = py(point.y);
    return '<g transform="translate(' + x.toFixed(1) + "," + (y + 44).toFixed(1) + ')">' +
      '<circle r="13" fill="#0F6B4F" stroke="#fff" stroke-width="2.5"/>' +
      '<path d="m -5 0 3.4 3.4 6.6 -6.8" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>' +
    "</g>";
  }

  function render(container, opts) {
    if (!container) return;
    if (container.__mapStop) {
      container.__mapStop();
      container.__mapStop = null;
    }

    var donor = opts.donor;
    var ngo = opts.ngo;
    var vol = opts.volunteer;
    var stage = opts.stage || "available";
    var progressFn = typeof opts.getProgress === "function" ? opts.getProgress : function () { return 0; };

    var routeMarkup = "";
    var legOnePath = null;
    var legTwoPath = null;

    if (donor && ngo) {
      var d1 = curve(vol ? vol.coords : donor.coords, donor.coords, -0.16);
      var d2 = curve(donor.coords, ngo.coords, 0.14);
      if (vol) legOnePath = d1;
      legTwoPath = d2;
      var full = (legOnePath ? legOnePath + " " : "") + legTwoPath;
      routeMarkup =
        '<path data-route-base d="' + full + '" fill="none" stroke="#A9B7A6" stroke-width="4" stroke-dasharray="8 9" stroke-linecap="round" opacity=".85"/>' +
        '<path data-route-progress d="' + full + '" fill="none" stroke="#0F6B4F" stroke-width="4.5" stroke-linecap="round"/>' +
        (vol ? '<g data-vehicle><circle r="16" fill="#08291E" stroke="#fff" stroke-width="3"/>' +
        '<text y="3.4" text-anchor="middle" font-size="8.5" font-weight="700" fill="#fff" font-family="Inter, system-ui, sans-serif">' +
        escapeXml(vol.short || "GO") + "</text></g>" : "");
    }

    var svg =
      '<svg viewBox="0 0 ' + W + " " + H + '" preserveAspectRatio="xMidYMid slice" role="img" aria-label="Simulated city map showing the donation route">' +
      baseMap() +
      (routeMarkup || "") +
      (donor ? pin(donor.coords, donor.name, "green") : "") +
      (ngo ? pin(ngo.coords, ngo.name, "amber", { labelBelow: true }) : "") +
      (vol && donor && ngo ? "" : vol ? pin(vol.coords, vol.name, "blue", { initials: vol.short }) : "") +
      (stage === "delivered" && ngo ? checkBadge(ngo.coords) : "") +
      "</svg>";

    container.innerHTML = svg;

    var svgEl = container.querySelector("svg");
    if (!svgEl || !donor || !ngo) return;

    var progressPath = svgEl.querySelector("[data-route-progress]");
    var vehicle = svgEl.querySelector("[data-vehicle]");

    var len1 = 0;
    if (legOnePath) {
      var tmp = document.createElementNS("http://www.w3.org/2000/svg", "path");
      tmp.setAttribute("d", legOnePath);
      var hidden = document.createElementNS("http://www.w3.org/2000/svg", "svg");
      hidden.style.position = "absolute";
      hidden.style.width = "0";
      hidden.style.height = "0";
      hidden.appendChild(tmp);
      container.appendChild(hidden);
      try { len1 = tmp.getTotalLength(); } catch (e) { len1 = 0; }
      if (!len1) len1 = Math.hypot(px(donor.coords.x) - px(vol.coords.x), py(donor.coords.y) - py(vol.coords.y)) * 1.04;
      hidden.remove();
    }

    var total = 0;
    try { total = progressPath.getTotalLength(); } catch (e) { total = 0; }
    if (!total) return;

    function frame() {
      var p = Math.max(0, Math.min(1, progressFn()));
      var fraction = 0;
      if (stage === "pickup") {
        fraction = len1 ? (p * len1) / total : p;
      } else if (stage === "picked_up") {
        fraction = (len1 + p * (total - len1)) / total;
      } else if (stage === "delivered") {
        fraction = 1;
      } else {
        fraction = 0;
      }
      var shown = Math.max(0, Math.min(total, fraction * total));
      progressPath.setAttribute("stroke-dasharray", shown.toFixed(1) + " " + total.toFixed(1));
      if (vehicle) {
        var pt;
        try { pt = progressPath.getPointAtLength(shown); } catch (e) { pt = { x: px(vol ? vol.coords.x : donor.coords.x), y: py(vol ? vol.coords.y : donor.coords.y) }; }
        vehicle.setAttribute("transform", "translate(" + pt.x.toFixed(1) + "," + pt.y.toFixed(1) + ")");
        vehicle.setAttribute("opacity", stage === "delivered" ? "0" : "1");
      }
      raf = requestAnimationFrame(frame);
    }

    var raf = requestAnimationFrame(frame);
    container.__mapStop = function () { cancelAnimationFrame(raf); };
  }

  global.RouteMap = { render: render };
})(window);
